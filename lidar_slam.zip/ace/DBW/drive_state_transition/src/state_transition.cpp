// this header incorporates all the necessary #include files and defines the class "ExampleRosClass"
#include "state_transition.h"
using namespace std;


#define ENABLE_USS_DRIVEOFF
//(ros::Time::now().toSec()-prev_time)>0.00)


State_Transition::State_Transition(ros::NodeHandle* nodehandle):n(*nodehandle)//have to pass nodehandle pointer into constructor for constructor to build subscribers
{ 
    //ROS_INFO("In class constructor of DriveOffROS");
    //Create Subscribers and Publishers here for initialisation or instance creation
    initializeSubscribers(); 
    initializePublishers();
    uint ArrayEp[10]={0};
    uint ArrayOh[10]={0};
    //initialize variables here, as needed
    //BCU_autoswitchStatus = false;
    flag_ResetUSSmapobj = false;
    timeUSS_delay = 0;    
    State_Status = 0;
    Localization = true;	
    Distance_Stop_frm_Obstacle = 3;
    Vehicle_Speed = 0;
    FOC_Decelerate = 0;
}

//member helper function to set up subscribers
void State_Transition::initializeSubscribers()
{
    //ROS_INFO("Initializing Subscribers");
    //&State_Transition::CANCallback is a pointer to a member function of State_Transition
    // "this" keyword is required, to refer to the current instance of State_Transition
    //can_subsciber_ = n.subscribe("/can_rx",1,&State_Transition::CANCallback,this);////This CANSubscriber will subscribe to the CAN Frames  
    zone_subscriber = n.subscribe("/ZoneInfo",1,&State_Transition::ZONECallback,this);
    lane_subscriber = n.subscribe("/RoadEnvStatus",1,&State_Transition::LANECallback,this);
	HMIStartTrip_subscriber = n.subscribe("/FromHMI_StartTrip",1,&State_Transition::HMIStartTripCallback,this);
	HMIResumeAD_subscriber = n.subscribe("/FromHMI_ResumeAD",1,&State_Transition::HMIResumeADCallback,this);

	//ROS_DBC_BRIDGE
	sub_VehicleInfo = n.subscribe("/VehicleInfo",1,&State_Transition::MsgCallback_VehicleInfo,this);	
	sub_RadarInfo = n.subscribe("/RadarInfo",1,&State_Transition::MsgCallback_RadarInfo,this);	
	string topicIDUSS[10] = {"id602", "id3F2", "id3F3", "id3F4", "id3F5", "id3F6", "id3F7", "id3F8", "id3F9", "id3FA"};	
    for (int i = 0; i < 10; i++)
	{
     	string topicUSS = topicIDUSS[i];
       	sub_idUSS[i] = n.subscribe(topicUSS,1,&State_Transition::MsgCallback_USS,this);	
    }
}

//member helper function to set up publishers;
void State_Transition::initializePublishers()
{
    //ROS_INFO("Initializing Publishers");
    //can_publisher_ = n.advertise<can_msgs::Frame>("/can_tx", 1, true);//to publish the CANFrames if required
    //can_publisher_Driveoff_ = n.advertise<can_msgs::Frame>("/can_tx", 1, true);//to publish the CANrames if required
    //state_publisher_= n.advertise<std_msgs::String>("/StateStatus", 1,true);// to publish the states
    status_publisher_= n.advertise<ace_msgs::VehicleStates>("/VehicleStates", 1,true);//to publish the different states defined by State machine structure
    percept_publisher_= n.advertise<std_msgs::String>("/PerceptionStatus", 1,true);
    driveOFF_publisher_ = n.advertise<std_msgs::Bool>("/DriveOffStatus",1,true);
    USS_EP_publisher_ = n.advertise<std_msgs::Int32MultiArray>("/USS_EP",1,true);
	ToHMIStartTripAck_publisher_ = n.advertise<std_msgs::Bool>("/ToHMIStartTripAck",1,true);	    	
    ToHMIResumeAD_publisher_= n.advertise<std_msgs::Bool>("/ToHMIResumeAD",1,true);
	ToHMIResumeADAck_publisher_= n.advertise<std_msgs::Bool>("/ToHMIResumeADAck",1,true);
    ToHMIJunction_publisher_= n.advertise<std_msgs::Bool>("/ToHMIJunction",1,true);
	ToHMISpecialZone_publisher_ = n.advertise<std_msgs::Bool>("/ToHMISpecialZone",1,true);
   
}

// This is where all the states are extracted from CAN frame and updated
// This function will be used to publish the MRR and USS CANFrames

void State_Transition::MsgCallback_VehicleInfo(const ace_msgs::VehicleInfo& msg )
{
	BCU_autoswitchStatus  = (bool)msg.AutoSwitchStatus;
	BCU_forwardgearStatus = (int) msg.DriveMode; 
	BCU_brakeStatus = (bool) msg.BrakeStatus;
	Vehicle_Speed = msg.VehicleSpeed;
	Vehicle_Speed = Vehicle_Speed * 10;    // Converted to m/s and internal value (.5625/.05625)
	State_Machine();
	ToHMIPublishers();    
}

void State_Transition::MsgCallback_RadarInfo(const ace_msgs::RadarInfo& msg)
{	
	MRR_FrameDEC = (float)msg.Radar_AccelerationRequest;
	//MRR_FrameDEC_factor = MRR_FrameDEC-140;
	PO_Distance = (float)msg.PObj0_Longitudinal;
	PO_Distance = (PO_Distance*20) + 140; //Temporary
    	ROS_INFO("PO_Distance : %f",PO_Distance);
	
}


void State_Transition::HMIStartTripCallback(const std_msgs::UInt8::ConstPtr& FromHMI_StartTripdata)
{
	
    FromHMI_StartTripinfo = (bool)FromHMI_StartTripdata -> data;
	
	if (FromHMI_StartTripinfo== true) 
	 {
	   FromHMI_StartTripdataPub.data = true;
	 }
	else
	{
 		FromHMI_StartTripdataPub.data = false;
	}
    ToHMIStartTripAck_publisher_.publish(FromHMI_StartTripdataPub);

  
}

void State_Transition::HMIResumeADCallback(const std_msgs::UInt8::ConstPtr& FromHMI_ResumeADdata)
{
    FromHMI_ResumeADinfo = (bool)FromHMI_ResumeADdata -> data;

	if (FromHMI_ResumeADinfo  == true) 
	 {
	   FromHMI_ResumeADdataPub.data = true;
	 }
	else
	{
 		FromHMI_ResumeADdataPub.data = false;
     }		

	ToHMIResumeADAck_publisher_.publish(FromHMI_ResumeADdataPub);
     
}


void State_Transition::MsgCallback_USS(const ace_msgs::IDUSS& msg)
{
	for (int i = 0; i < 10; i++)
	{
		ArrayEp[i] = msg.sigSIP_MAP_01_ExistProbability;
		ArrayOh[i] = msg.sigSIP_MAP_01_ObjectHeight;
	}
}

void State_Transition::ZONECallback(const std_msgs::UInt8::ConstPtr& zone_data)
{
    zone_info = (e_ZoneInfo)zone_data -> data;
    //cout<<"Zone info is available:";
    //cout<<zone_info<<endl;  
}


void State_Transition::LANECallback(const std_msgs::UInt8::ConstPtr& lane_data)
{
 
    lane_info = (e_RoadEnvStatus)lane_data -> data;
    //cout<<"Lane info is available:";
    //cout<<lane_info<<endl;

}

 void TIMERCallback(const ros::TimerEvent& event)
{
    if(timer_flag == 1)	
  	counter ++;	
   
}



void State_Transition::ToHMIPublishers()
{
	if(zone_info == JunctionZone)
	{
		ToHMI_Junction.data = true;
		Previous_active_state = JunctionZone;
	}

	else 
	{
		ToHMI_Junction.data = false;
			
	}
	
	ToHMIJunction_publisher_.publish(ToHMI_Junction);

	if((zone_info == LaneZone) && (lane_info == OK) && (Previous_active_state == JunctionZone))
	{
		if(timer_HMI < 200)
		{

			ToHMI_ResumeAD.data = true;
			
			timer_HMI++;
		}
		else
		{
			ToHMI_ResumeAD.data = false;
			Previous_active_state = LaneZone;
			timer_HMI =0;
		}

	}	
	else
	{
		ToHMI_ResumeAD.data = false;	
		timer_HMI =0;
	}
	
	ToHMIResumeAD_publisher_.publish(ToHMI_ResumeAD);
	
	if(zone_info ==SpecialZone)
	{
		ToHMI_ResumeSpecialZone.data = true;
	}
	else
	{
		ToHMI_ResumeSpecialZone.data = false;
	}
	ToHMISpecialZone_publisher_.publish(ToHMI_ResumeSpecialZone);
}


 
void State_Transition::State_Machine()    
{
    //set USS to false
    USS_StartStop_latched = false; 
				
    if(MRR_FrameDEC > 0)
	{
		MRR_acceleration = true; 
	}
	else
	{
		MRR_acceleration = false;
	}
	
	//ROS_INFO("Vehicle_Speed : %ld",Vehicle_Speed);
	//ROS_INFO("RADAR Accelertion,PO_Distance  : %d,%d",MRR_FrameDEC,PO_Distance);	

	
#ifdef ENABLE_USS_DRIVEOFF
    
	USS_frame_map_reset.id = 0x165;
	USS_frame_map_reset.data[0] = 0;
	USS_frame_map_reset.data[1] = 0;
	USS_frame_map_reset.data[2] = 0;
	USS_frame_map_reset.data[3] = 0;
	USS_frame_map_reset.data[4] = 0;
	USS_frame_map_reset.data[5] = 0;
	USS_frame_map_reset.data[6] = 0;
	USS_frame_map_reset.data[7] = 0;
	


	USS_GreatestEp = ArrayEp[0];
	USS_GreatestOh = ArrayOh[0];
    
    driveOFF_Boolean.data = USS_StartStop;
	//driveOFF_publisher_.publish(driveOFF_Boolean);
	
    for(index=1; index < 10; index++)
	{	
		//checking for the greatest Existence probability
		if(ArrayEp[index] > USS_GreatestEp) 
		{
			USS_GreatestEp = ArrayEp[index];
			// finding the height of the object with greatest probability
			USS_GreatestOh = ArrayOh[index]; 
		}
	}


/*
	hsm1owt, 18th Oct 2019
	OBSERVATION: When a static object is placed with vehicle speed =0, Object height = Unknown or High (2 or 3) is consistently detected. \If the object moves but still in the path of the vehicle OH value changes to low intermitently. .

*/
//Logic as recommended by Madhu H N
	USS_StartStop = ((USS_GreatestEp==10) &&((USS_GreatestOh >= 0x02))) ? true : false;
	

	if(USS_StartStop == true)
	{
		USS_StartStop_latched = true;
 		timeUSS_delay = 0;
     	flag_ResetUSSmapobj = false;
    }
	else
	{
	    ////ROS_INFO("Switched:%d",timeUSS_delay);

		if (false == flag_ResetUSSmapobj)
		{
			USS_frame_map_reset.data[1] = 0x01;
			//can_publisher_.publish(USS_frame_map_reset);
			flag_ResetUSSmapobj = true;
		}	

		if(timeUSS_delay > 1000)//6000
		{
		  USS_StartStop_latched = false;
		  timeUSS_delay = 0;
		}
		else
		{
		 timeUSS_delay++;
		}
	}
    // //ROS_INFO("GEp:%d,GOh:%d,USS State: %d, USS Latched: %d",USS_GreatestEp,USS_GreatestOh,USS_StartStop,USS_StartStop_latched);

#endif //ENABLE_USS_DRIVEOFF

	
//HLC1KOR
//State Manipulation
	
	Distance_Stop_frm_Obstacle = 3 ;    //To Test Stopping distance

//initially Manual State
	
	if (BCU_autoswitchStatus == false)
	{
		main_currentstate = MANUAL;
		//cout << "Vehicle is in MANUAL Mode!"<<endl;
		ROS_INFO("Vehicle is in MANUAL Mode!");
	
	}	
	
	status_variable.MainState = main_currentstate;
	status_publisher_.publish(status_variable);
	status_variable.ActiveState = active_currentstate;
	status_publisher_.publish(status_variable);


	switch (main_currentstate) 
	{

		case MANUAL:
			
			if (BCU_autoswitchStatus == false) //check for Auto switch
			{ 
				//cout << "Vehicle is in MANUAL Mode!" <<endl;
				ROS_INFO("Vehicle is in MANUAL Mode!");				
				main_currentstate = MANUAL;
						
			}
			
			else
				main_currentstate = PAUSE; 

			active_currentstate = DRIVEOFF;

		break;


		case PAUSE: 
			
			 //Auto is ON but gear is not set to Forward
			if (((BCU_forwardgearStatus == false) || (BCU_brakeStatus == false)) || ((FromHMI_StartTripinfo == false) && (FromHMI_ResumeADinfo == false)))
		{
				//cout << "Vehicle is in PAUSE state!"<<endl;
				ROS_INFO("Vehicle is in pause state!");				
				main_currentstate = PAUSE;
		}
		
	 // Both Auto and Forward gear are set

			else if ((BCU_forwardgearStatus == true) && (BCU_autoswitchStatus == true) && (BCU_brakeStatus == true) && ((FromHMI_StartTripinfo == true) || (FromHMI_ResumeADinfo == true)))
				main_currentstate = ACTIVE;
			
			else
				main_currentstate = MANUAL;
				
			active_currentstate = DRIVEOFF;

		break;


		case ACTIVE:
		
			active_flag = BuggyActiveState();
			
			if (active_flag == 0 && BCU_forwardgearStatus == true && BCU_brakeStatus == true) 
			{	
				main_currentstate = ACTIVE;
				//cout << "Vehicle is in Active State!"<<endl;
			}
			
			else if (active_flag == 1)
				main_currentstate = FAILURE;
			
			else 
				main_currentstate = PAUSE; 
		
		break;

		
		case FAILURE:
		   //cout << "Error: Vehicle has entered FAILURE State!"<<endl;
			ROS_INFO("Error: Vehicle has entered FAILURE State!");
		
			active_currentstate = DRIVEOFF;

		break;
		

	}//End Switch
	
	
		
}		



int State_Transition::BuggyActiveState()
{
	//initially Obstacle Handler State
	
/*	if ((MRR_acceleration == false) || (USS_StartStop_latched == true) || ((PO_Distance <= (Distance_Stop_frm_Obstacle+1))&&(PO_Distance != 0)))
	{
		active_currentstate = OBSTACLEHANDLER;
		//cout << "OBSTACLE DETECTED!"<<endl;
		ROS_INFO("OBSTACLE DETECTED!");		
		timer_flag = 0;	
		counter = 0;
	}	*/
	//else
	//	active_currentstate = DRIVEOFF;

	
	switch (active_currentstate)
	{
		case OBSTACLEHANDLER:
			
			if ((MRR_acceleration == true) && (USS_StartStop_latched == false) && ((PO_Distance >= (Distance_Stop_frm_Obstacle+1))||(PO_Distance == 0)))
			{
				active_currentstate = DRIVEOFF;
				return 0;
				
			}	
				
				
			else
			{
				active_currentstate = OBSTACLEHANDLER;
				//cout << "OBSTACLE DETECTED!"<<endl;
				ROS_INFO("OBSTACLE DETECTED!");				
				return 0;
			}
			
			 	
		break;
		
		
		case DRIVEOFF:
		     ROS_INFO("lane_info: %d", lane_info);
			//Always check for obstacle first
			if (((MRR_acceleration == true) || ((PO_Distance >(Distance_Stop_frm_Obstacle+1)) || (PO_Distance == 0) ))&& (USS_StartStop_latched == false) )
			{
				//cout<<"Vehicle is in DRIVEOFF state!"<<endl;
				ROS_INFO("Vehicle is in DRIVEOFF state!");			 	
				if (zone_info == LaneZone) //Lane Zone
				{
					if((counter < LANE_WAIT_TIME) && (lane_info == false))	 // Wait for 3 seconds before going to failure	    
					{
						timer_flag = 1;
						//cout<<"Vehicle is in DRIVEOFF state!"<<endl;
						ROS_INFO("Vehicle is in DRIVEOFF state!");							
						active_currentstate = DRIVEOFF;
						return 0;
					}		
						
					else
					{	
						timer_flag = 0;
						counter = 0;

						if (lane_info == NotOK) //vehicle is in lane_zone but lane not detected: FAILURE!
						{
							active_currentstate = OBSTACLEHANDLER;							
							return 1;
						}
						else if (lane_info == OK) //vehicle is in lane_zone and lane is also detected
						{
							active_currentstate = DRIVEINLANE;		
							return 0;
						}
					}
				}	
				else if (zone_info == JunctionZone) //Junction Zone
				{
					active_currentstate = JUNCTION;
					timer_flag = 0;
					counter = 0;
					return 0;
				}
				else if (zone_info == SpecialZone) //Special Zone
				{
					active_currentstate = SPECIALZONE;
					timer_flag = 0;
					counter = 0;
					return 0;
				}
			   		
				
			}	
			
			else
			{
				timer_flag = 0;	
				counter = 0;
						
				active_currentstate = OBSTACLEHANDLER;
				return 0;				
			}
		
		break;
		
		
		case DRIVEINLANE:
		
			//Always check for obstacle first
				if ((MRR_acceleration == true) || ((PO_Distance >8) || (PO_Distance == 0)))
			{
				active_currentstate = DRIVEINLANE;	
				//cout << "Vehicle is in DRIVEINLANE state!" <<endl;
				ROS_INFO("Vehicle is in DRIVEINLANE state!");				
							
				if (zone_info == LaneZone) //Lane Zone
				{
					if (lane_info == NotOK) //vehicle is in lane_zone but lane not detected: FAILURE!
					{	
						if((counter < LANE_WAIT_TIME) && (lane_info == false))	 // Wait for 3 seconds before going to failure		    
						{
							timer_flag = 1;
							active_currentstate = DRIVEINLANE;
							ROS_INFO("Vehicle is in DRIVEINLANE state!");
							return 0;
						}
						else
						{	
							timer_flag = 0;
							counter = 0;
							active_currentstate = OBSTACLEHANDLER;							
							return 1;
						}	
					}
					else if (lane_info == OK) //vehicle is in lane_zone and lane is also detected
					{
						active_currentstate = DRIVEINLANE;		
						timer_flag = 0;
						counter = 0;
						return 0;
					}
				}	
				else if (zone_info == JunctionZone) //Junction Zone
				{
					active_currentstate = JUNCTION;
					timer_flag = 0;
					counter = 0;
					return 0;
				}
				else if (zone_info == SpecialZone) //Special Zone
				{
					active_currentstate = SPECIALZONE;
					timer_flag = 0;
					counter = 0;
					return 0;
				}
					else if (zone_info == GoalZone) //Special Zone
				{
					active_currentstate = GOAL;
					timer_flag = 0;
					counter = 0;
					return 0;
				}
				
			}	
			
			else
			{			
				active_currentstate = OBSTACLEHANDLER;
				timer_flag = 0;
				counter = 0;
				return 0;			
			}
			
	
		
		break;
		
		
		case JUNCTION: 
			
			if (zone_info == JunctionZone) //Junction Zone
				{
					active_currentstate = JUNCTION;
					//cout << "Vehicle has entered JUNCTION!"<<endl;
					ROS_INFO("Vehicle has entered JUNCTION!");
					return 0;
				}
						
			else if (zone_info == GoalZone) //Goal
			{
				active_currentstate = GOAL;
				return 0;
			}
			else
			{
				active_currentstate = DRIVEINLANE;
				return 0;
			}
			
				
		break;
		
		
		case SPECIALZONE:
			
			if (zone_info == SpecialZone) //Special Zone
				{
					active_currentstate = SPECIALZONE;
					//cout << "Vehicle has entered SPECIALZONE!"<<endl;
					ROS_INFO("Vehicle has entered SPECIALZONE!");					
					return 0;
				}
						
			else if (zone_info == GoalZone) //Goal
			{
				active_currentstate = GOAL;
				return 0;
			}
			else
			{
				active_currentstate = DRIVEINLANE;
				return 0;
			}
			
									
		break;
		
		
		case GOAL:
			//cout << "Drive Complete, Vehicle has reached the Goal!"<<endl;
			ROS_INFO("Drive Complete, Vehicle has reached the Goal!");
		break;
		
	}
	
	
	
	
}

//end HLC1KOR





int main(int argc, char** argv)
{
    // ROS set-ups:
    ros::init(argc, argv, "socketcan_driveby_wire_ROS_node"); //node name
    ros::NodeHandle n("") ,n_param("~"),nh; // create a node handle; need to pass this to the class constructor
    ros::Timer timer = nh.createTimer(ros::Duration(0.1), TIMERCallback);
    State_Transition DriveByWire(&n);  //instantiate an ExampleRosClass object and pass in pointer to nodehandle for constructor to use

    ros::spin();
    return 0;
}
