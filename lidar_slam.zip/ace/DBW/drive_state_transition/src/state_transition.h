#ifndef EXAMPLE_ROS_CLASS_H_
#define EXAMPLE_ROS_CLASS_H_
#define LANE_WAIT_TIME 30 //30 for 3 seconds
//some generically useful stuff to include...
#include <math.h>
#include <stdlib.h>
#include <string>
#include <vector>
#include <iostream>
#include <chrono>

#include <ros/ros.h> //ALWAYS need to include this
#include <can_msgs/Frame.h>
#include <sensor_msgs/Joy.h>
#include <geometry_msgs/Twist.h>

#include <geometry_msgs/Point.h>
#include <sensor_msgs/NavSatFix.h>
#include <sensor_msgs/Imu.h>

//header needed for dbc_ros_bridge(decode/encode)
//decode
#include <ace_msgs/RadarInfo.h>
#include <ace_msgs/IDUSS.h>
#include <ace_msgs/VehicleInfo.h>

//encode
#include <ace_msgs/ID173.h>
#include <ace_msgs/VehicleStates.h>

//message types used in this example code;  include more message types, as needed
#include <std_msgs/Bool.h>
#include <std_msgs/Float32.h>
#include <std_msgs/String.h>
#include <std_msgs/Int32MultiArray.h>
#include <std_msgs/Int8.h>
#include <std_msgs/UInt8.h>

//SOCKETCAN LIBRARIES

#include <string>

using namespace std;


//HLC1KOR
static int timer_flag;
static int active_flag;
static bool FromHMI_StartTripinfo;
static bool FromHMI_ResumeADinfo;

enum e_ZoneInfo
{NotEvaluated = 0, LaneZone, JunctionZone, SpecialZone, GoalZone, Unknown_Zone = 255}; 
 e_ZoneInfo zone_info;

enum e_RoadEnvStatus 
{Unknown_Lane = 0, OK, NotOK}; 
e_RoadEnvStatus lane_info;

//end HLC1KOR


static int State_Status;
static int T_Wait = 0;
static int T_Calibratable = 2500;
static bool TransitStatus;
static bool Transit_Status;


static bool Localization ;
static long counter;
static long Timer_speedrampdown;



// define a class, including a constructor, member variables and member functions
class State_Transition
{
public:
    State_Transition(ros::NodeHandle* nodehandle ); //"main" will need to instantiate a ROS nodehandle, then pass it to the constructor
    // The above line is a constructor prototype declaration

    //class variables----------------------------------------------------------------------------
    //bool type
	
    int index;
    bool BCU_autoswitchStatus;
    bool BCU_forwardgearStatus;
	bool BCU_brakeStatus;
    //HLC1KOR
    enum MainState{MANUAL, PAUSE, ACTIVE, FAILURE}; //Main States of the Vehicle
    MainState main_currentstate;
	
    enum ActiveState{DRIVEOFF, DRIVEINLANE, SPECIALZONE, OBSTACLEHANDLER, JUNCTION, GOAL}; //States inside the Active state
    ActiveState active_currentstate;
    //end HLC1KOR
	
    std_msgs::String msg;
    bool negative_8;
    bool negative_4;
    float  MRR_FrameDEC;
    bool driveoff_pub_flag;
    signed int  MRR_FrameDEC_factor;
    std_msgs::Bool driveOFF_Boolean;
	std_msgs::Bool FromHMI_StartTripdataPub;
	std_msgs::Bool FromHMI_ResumeADdataPub;
    std_msgs::Bool ToHMI_Junction;
    std_msgs::Bool ToHMI_ResumeAD;
	std_msgs::Bool ToHMI_ResumeSpecialZone;
    ace_msgs::VehicleStates status_variable;
    std_msgs::Int32MultiArray EP;	
    bool flag_ResetUSSmapobj;
    long timeUSS_delay;	
    int Speed_ramp;
    double Vehicle_Speed;
    float PO_Distance;
    double  FOC_Decelerate;
    double Vehicle_Speed_output;
    bool MRR_acceleration;
    bool USS_StartStop;
	
    bool USS_StartStop_latched;
    int  Distance_Stop_frm_Obstacle;
    bool TimeUpdate();// for updating the transition status
    int Previous_active_state;
	int timer_HMI;

    //MRR CAN frame variable 
    can_msgs::Frame MRR_frame; // need this to receive can messges from RADAR
    //USS
    can_msgs::Frame USS_frame3F1;
    can_msgs::Frame USS_frame3F2;
    can_msgs::Frame USS_frame3F3;
    can_msgs::Frame USS_frame3F4;
    can_msgs::Frame USS_frame3F5;
    can_msgs::Frame USS_frame3F6;
    can_msgs::Frame USS_frame3F7;
    can_msgs::Frame USS_frame3F8;
    can_msgs::Frame USS_frame3F9;
    can_msgs::Frame USS_frame3FA;
    can_msgs::Frame USS_frame_map_reset; 	
    can_msgs::Frame Driveoff_Frame;


    uint Ep3F1;
    uint Ep3F2;
    uint Ep3F3;
    uint Ep3F4;
    uint Ep3F5;
    uint Ep3F6;
    uint Ep3F7;
    uint Ep3F8;
    uint Ep3F9;
    uint Ep3FA;
    

    uint Oh3F1;
    uint Oh3F2;
    uint Oh3F3;
    uint Oh3F4;
    uint Oh3F5;
    uint Oh3F6;
    uint Oh3F7;
    uint Oh3F8;
    uint Oh3F9;
    uint Oh3FA;
    
    uint ArrayEp[10];
    uint ArrayOh[10];
    
    uint USS_GreatestEp;
    uint USS_GreatestOh;

    //HLC1KOR
    int BuggyActiveState();
    // end HLC1KOR
   
    

    
    // define public or private methods and public or private variables
private:
    //ROS definition which are standard by nature and needs to be private ------------------------
    ros::NodeHandle n,n_param,nh; // Object which represents the ROS node, NodeHandle created will actually do the initialization of the node

    //Subscribers---------------------------------------------------------------------------------
    ros::Subscriber can_subsciber_;
    //HLC1KOR
    ros::Subscriber HMIStartTrip_subscriber;
    ros::Subscriber HMIResumeAD_subscriber;
    ros::Subscriber zone_subscriber;
    ros::Subscriber lane_subscriber;
    ros::Subscriber sub_VehicleInfo;
    ros::Subscriber sub_RadarInfo;
    ros::Subscriber sub_idUSS[10] ;
    //END HLC1KOR
    

    //Publishers----------------------------------------------------------------------------------
    ros::Publisher can_publisher_;
    ros::Publisher can_publisher_Driveoff_;
    ros::Publisher state_publisher_;
    ros::Publisher driveOFF_publisher_;
    ros::Publisher status_publisher_;
    ros::Publisher USS_EP_publisher_;	    	
    ros::Publisher percept_publisher_;	
    //HLC1KOR
    ros::Publisher ToHMIStartTripAck_publisher_;
    ros::Publisher ToHMIResumeAD_publisher_;	    	
    ros::Publisher ToHMIResumeADAck_publisher_;
    ros::Publisher ToHMIJunction_publisher_;	
	ros::Publisher ToHMISpecialZone_publisher_;
    //end HLC1KOR


    //Generic functions --------------------------------------------------------------------------
    void initializeSubscribers(); // we will define some helper methods to encapsulate the gory details of initializing subscribers, publishers and services
    void initializePublishers();


    //prototype for callback of CAN subscriber
   
    void CANCallback(const can_msgs::Frame& CANframe);//prototype for callback of CAN subscriber
    //HLC1KOR
    void State_Machine();
    void ToHMIPublishers();
    void HMIStartTripCallback(const std_msgs::UInt8::ConstPtr& FromHMI_StartTripdata);
    void HMIResumeADCallback(const std_msgs::UInt8::ConstPtr& FromHMI_ResumeADdata);
    void ZONECallback(const std_msgs::UInt8::ConstPtr& zone_data);
    void LANECallback(const std_msgs::UInt8::ConstPtr& lane_data);
    void TIMERCallback(const ros::TimerEvent& event);
    void MsgCallback_VehicleInfo(const ace_msgs::VehicleInfo& msg);
    void MsgCallback_RadarInfo(const ace_msgs::RadarInfo& msg);
    void MsgCallback_USS(const ace_msgs::IDUSS& msg);
    //end HLC1KOR

    //Other useful funtions 
   
   



}; // note: a class definition requires a semicolon at the end of the definition

#endif  // this closes the header-include...ALWAYS need one of these to match #ifndef
