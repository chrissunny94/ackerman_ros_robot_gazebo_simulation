sudo modprobe peak_usb
#sudo modprobe pcan

sudo ip link set can0 down
sudo ifconfig can0 txqueuelen 1000
sudo ip link set can0 up type can bitrate 500000 




sudo ip link set can1 down
sudo ifconfig can1 txqueuelen 1000
sudo ip link set can1 up type can bitrate 500000

