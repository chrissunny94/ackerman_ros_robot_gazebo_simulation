# -*- coding: utf-8 -*-
"""
Created on Wed Dec  4 10:57:15 2019

@author: KLI6KOR
"""

import cantools

dbcfilename = 'CURTIS_CAN.DBC'
def remove0(string1):
        
    l = list(string1)  # convert to list
       
    p = l.index("0")  # find position of the letter "a"
    del(l[p])         # delete it
    string1 = "".join(l)  # convert back to string
    return string1
    
if __name__ == '__main__':
    db = cantools.database.load_file(dbcfilename)
    #print(db)
    messages = db.messages
    #print(messages)
    for i in messages:
        name1 = str(str(i.name)+str(hex(i.frame_id)))+".msg"
        name = remove0(name1)
        #print(name)
        f= open(name,"w+")
        for j in i.signals:
            signals = "int32_t "+j.name+"\n"
            #print(signals)
            f.write(signals)
        f.close()   
        
 