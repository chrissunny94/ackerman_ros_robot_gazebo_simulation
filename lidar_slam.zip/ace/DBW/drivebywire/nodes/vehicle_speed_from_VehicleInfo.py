#!/usr/bin/python
#encoding:utf-8

import rospy
from std_msgs.msg import Int64
from std_srvs.srv import SetBool

from can_msgs.msg import Frame
from std_msgs.msg import String ,Float32
import pprint
from ace_msgs.msg import VehicleInfo

import cantools

import rospkg

# get an instance of RosPack with the default search paths
rospack = rospkg.RosPack()

# list all packages, equivalent to rospack list
rospack.list() 

# get the file path for rospy_tutorials
path = rospack.get_path('drivebywire')


class USS_Node:
    def __init__(self):
        self.debug = False
        
        
        self.speed_pub_ = rospy.Publisher('/VehicleInfo/VehicleSpeed', Float32, queue_size=50)
        #self.CAN_subsriber = rospy.Subscriber("/can_rx", Frame, self.CAN_callback)
        self.VehicleInfo_subsriber = rospy.Subscriber("/VehicleInfo", VehicleInfo, self.VehicleInfo_callback)
        
        rospy.loginfo("Class initiated successfully ! \n Now let the callbacks do the rest")
        
        
    
    def VehicleInfo_callback(self,DATA):
        self.speed_pub_.publish(DATA.VehicleSpeed)
        
        
    
if __name__ == '__main__':
    rospy.init_node('VehicleSpeed')
    rospy.loginfo("VehicleSPeedNode")
    USS_Node()
    rospy.spin()
