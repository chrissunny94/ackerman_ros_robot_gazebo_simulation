#!/usr/bin/python
#encoding:utf-8

import rospy
from std_msgs.msg import Int64
from std_srvs.srv import SetBool

from can_msgs.msg import Frame
from std_msgs.msg import String ,Float64
import pprint
from ace_msgs.msg import ID125

import cantools

import rospkg

# get an instance of RosPack with the default search paths
rospack = rospkg.RosPack()

# list all packages, equivalent to rospack list
rospack.list() 

# get the file path for rospy_tutorials
path = rospack.get_path('drivebywire')


class USS_Node:
    def __init__(self):
        self.debug = False
        
        print "PATH=", path + "/CAN_DBC/CURTIS_CAN.dbc"
        self.dbc_file = open(path + "/CAN_DBC/CURTIS_CAN.dbc", "r")   
        self.db = cantools.database.load(self.dbc_file)
        self.pp = pprint.PrettyPrinter(indent=4)
        self.speed_pub_ = rospy.Publisher('/longitudinal_velocity', Float64, queue_size=50)
        #self.CAN_subsriber = rospy.Subscriber("/can_rx", Frame, self.CAN_callback)
        self.ID125_subsriber = rospy.Subscriber("/id125", ID125, self.ID125_callback)
        
        rospy.loginfo("Class initiated successfully ! \n Now let the callbacks do the rest")
        
        
    def CAN_callback(self,Frame):
        if(self.debug):
            rospy.loginfo("\n"+rospy.get_caller_id() + " I heard %s %s", Frame.id,Frame.data)
        
        #APointX = output.get('sigSIP_MAP_01_1stPointY')
        data = Frame.data
        
        if(Frame.id == 0x125):
            
            output = self.db.decode_message(Frame.id, bytearray(Frame.data))
            Vehicle_Speed = output.get('CURTIS_VehicleSpeed')
            print(Vehicle_Speed)
            self.speed_pub_.publish(Vehicle_Speed*0.27778 ) #Converting to m/s from km/hr

    def ID125_callback(self,DATA):
        self.speed_pub_.publish(DATA.ESC_VehicleSpeed*.2778)
        
        
    
if __name__ == '__main__':
    rospy.init_node('USS_Object_tracker_Node')
    rospy.loginfo("Starting the USS node")
    USS_Node()
    rospy.spin()
