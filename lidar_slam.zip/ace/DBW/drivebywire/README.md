<a href=""><img src="https://connectedautomateddriving.eu/wp-content/uploads/2018/11/bosch-logo-300x300.jpg" align="center" width="190"></a>



---------------------------------------------------------------------------------------------

#Drive By wire

This Node will provide the Drive by wire control for the buggy

==***Published ROS Topics***==

|Topic name| Message type  |Who uses this ?|Unit|
|---------------|--------------------|-------------------- |------|
|/can_tx| [can_msgs/Frame.msg](http://docs.ros.org/melodic/api/can_msgs/html/msg/Frame.html) | This is goes out to the **public can** via socketcan| N/A|
|/longitudinal_velocity| [std_msgs/Float64.msg](http://docs.ros.org/melodic/api/std_msgs/html/msg/Float64.html) | Vehicle speed from CURTIS |m/s |




==***Subscribed ROS topics***==

|Topic name| Message type  |Who gives this input  | unit|
|---------------|--------------------|----------------------------|------|
|/req_steer| [std_msgs/Float64.msg](http://docs.ros.org/melodic/api/std_msgs/html/msg/Float64.html) | This is for setting the steering angle|radians |
|/throttle_level| [std_msgs/Int32.msg](http://docs.ros.org/api/std_msgs/html/msg/Int32.html) | This is for setting the steering angle|int value from 0-100|


|||   
This node will talk to the Curtis controller to move the buggy in a desired manner .



### Steps to build

Make a workspace 

	mkdir  ~/workspace/src -p
	cd  ~/workspace/src


### Clone the Repo

	git clone https://sourcecode.socialcoding.bosch.com/scm/lsad/drivebywire.git 
	


### Build the code

	catkin build
	
source the build code to the ENV variables 

	source devel/setup.bash
	

## RUN the code

	roslaunch drivebywire drive_by_wire.launch
	
## make the vehicle speed available


## Load driver manually:
---------------------------------------------------------------------------------------
Set-up udev rules or type manually:

	sudo modprobe peak_usb # kernel driver, since 3.11

	sudo modprobe peak_pci # kernel driver

	sudo modprobe pcan # PEAK vendor driver

	sudo modprobe esd_usb2 # kernel driver

Initialize NIC
	
	sudo ip link set can0 up type can bitrate 500000 # adjust bitrate as 	needed


## Bring-up CAN NIC (Linux kernel drivers) automatically:
-------------------------------------------------------------------------------------------
	
 For automatic set-up, the network can be configured in 

	echo "allow-hotplug can0
	iface can0 can static
    	bitrate 500000" | sudo tee -a /etc/network/interfaces

Or by adding the following contents to /etc/network/interfaces

	allow-hotplug can0
	iface can0 can static
    	bitrate 500000
	#    up ip link set $IFACE txqueuelen 20 # uncomment if more than 4 nodes are used

### Tools and Debugging:
---------------------------------------------------------------------------------------

socketcan_dump

Simple test program provided with the package, just prints the received messages:

	rosrun socketcan_interface socketcan_dump can0

Netlink status

	ip -details -statistics link show can0

(not available for all drivers)

	can-utils

Feature-rich tool suite for SocketCAN, install with:

	sudo apt-get install can-utils
	

Example for displaying messages from canbus 
	
    candump can0
    
To filter out message 


 
 To send messages on canbus
 
    cansend can0 123#1122334455667788
    

When using the candump utility, you must specify filters as an identifier and mask. For example, to receive only frames with identifier 0x100 on the can0 interface:

	candump can0,100:7FF

To receive all frames between 0x100 and 0x1FF inclusive:

	candump can0,100:700

The candump utility also allows for applying negated filters, which receive a message when the filter rule is not matched. For example, to matche all frames except those with identifiers between 0x100 and 0x1FF inclusive:

	candump can0,100~700





## Docupedia link
+++++++++++++++++++++++++++++++++++++++

[https://sourcecode.socialcoding.bosch.com/projects/LSAD/repos/drivebywire/browse](https://sourcecode.socialcoding.bosch.com/projects/LSAD/repos/drivebywire/browse) 
 