#include <drivebywire/drivebywire.h>
#define DEC_VALUE_ZERO_NM_STEER 	1023
#define HOLD_STEERING_POS_OFFSET	100
#define CORRECTION_VALUE			50
#define MAX_STEER_TORQ_ALLOWED		80
#define CONST_STEP_SIZE				10
#define TORQUE_STEP_TO_HOLD			(HOLD_STEERING_POS_OFFSET/CONST_STEP_SIZE)
#define ALLOWED_TORQUE_LIMIT		200
#define UPPER_LIMIT_TORQ			(DEC_VALUE_ZERO_NM_STEER + ALLOWED_TORQUE_LIMIT)
#define LOWER_LIMIT_TORQ			(DEC_VALUE_ZERO_NM_STEER - ALLOWED_TORQUE_LIMIT)
#define PID_KICKOFF_VAL				(-50)



#define ABS_DIFF(A,B) ((A>B) ? (A-B):(B-A))
#undef OPERATE_ONLY_RIGHT
#define DEFAULT_PREV_ERROR_VAL (-200)
using namespace std;

dbw_joystick_node::dbw_joystick_node(ros::NodeHandle* nodehandle):nh_(*nodehandle)
{ // constructor
    ROS_INFO("in class constructor of Drive by wire");
    initializeSubscribers(); // package up the messy work of creating subscribers; do this overhead in constructor
    initializePublishers();
	initializeVariables();


}

void dbw_joystick_node::initializeVariables(){

    val_to_remember_=0.0;
    speed_level = 0;
    Control_Status = false;
    last_Control_Status = false;


    // can also do tests/waits to make sure all required services, topics, etc are alive


    steering_hex_prap=0;
    steering_hex_Inte=0;
    steering_hex_Inte_old=0;
    steering_hex_Diff=0;
    steering_hex_Diff_old=0;

    prev_time = 0;
    KP = 0;
    KI = 0;
    KD = 0;
    cumError =0;
    rateError =0;
    lastError =0;
	KD_Slope = 0;


	JoyStick_Press_Status = false;
	Steering_Send_Status =  false;

	steering_hex = DEC_VALUE_ZERO_NM_STEER;
    Torque_map[0]=10;
	index_tor = 0;
	AcceptNewRequest = true;
	Control_Steer = true;
	Turn_Right = false;
	Prev_steering_hex = 0;
	PID_factor = 0;
	ErroratStart = 1;
	Tuning_val_band = BAND3;
	Turn_direction = Rforward;
	SignedAngle = 0;
	//These are the two variables , you will be using to generate the CAN frame for DBW functionality
	Requested_Steer_Angle = 0;
	Prev_Steer_Angle = 0;
	Throttle_level = 0;
	correction_ctr = 0;
	torque_zerocrossover = 0;
	PrevTimeval = ros::Time::now();
	CurTimeval = ros::Time::now();

	mCood_Brake_Auto_Enable = 0;
	mCood_SetBrakeReq = 0;
	mCood_SetVehSpeed = 0;
	mCood_Steer_Auto_Enable = 0;
	mCood_SteeringControlMaster = 0;
	mCood_Vehicle_Speed_Auto_Enable = 0;


	wheelbase = 2.8;



}

void dbw_joystick_node::initializeSubscribers()
{
    ROS_INFO("Initializing Subscribers");
    joy_sub_ = nh_.subscribe("/LSAD/joy", 1, &dbw_joystick_node::joyCallback,this);
    steeringinfo_sub_ = nh_.subscribe("/SteeringInfo",1,&dbw_joystick_node::SteeringInfoCallback,this);
	cmdvel_sub_ = nh_.subscribe("/cmd_vel",1,&dbw_joystick_node::cmdvelCallback,this);
	VehicleControlCOOR_sub_ = nh_.subscribe("/VehicleControlCOOR",1,&dbw_joystick_node::VehicleControlCOORCallback,this);
	steer_req_sub_ = nh_.subscribe("/req_steer",1,&dbw_joystick_node::steerReqCallback,this);
	VehicleInfo_sub_ = nh_.subscribe("/VehicleInfo",1,&dbw_joystick_node::VehicleInfoCallback,this);

}


void dbw_joystick_node::VehicleInfoCallback(const ace_msgs::VehicleInfo& data){

current_vehicle_speed = data.VehicleSpeed;
Autoswitch_Status  = bool(data.AutoSwitchStatus);



}



void dbw_joystick_node::steerReqCallback(const std_msgs::Float32& SteerReq){

	int iValue = (int)SteerReq.data;
	CurTimeval = ros::Time::now();
//if((CurTimeval.nsec - PrevTimeval.nsec)>(1000000000/4))
	if((CurTimeval.sec - PrevTimeval.sec)>1)
	{
		//if(Prev_Steer_Angle!= iValue )
		//{
			PrevTimeval = ros::Time::now();
			ROS_INFO ("Prev Req Error:%f(%d)",SignedAngle,Requested_Steer_Angle);
	//		ROS_INFO("NextReq:%f,PrevTargetReq:%d,CurrentAngle:%f	\n", SteerReq.data,Requested_Steer_Angle,SignedAngle);
	
			AcceptNewRequest = true;
			Prev_Steer_Angle = (int)SteerReq.data;
			Requested_Steer_Angle = (int)SteerReq.data;
			torquebasedsteerFunction();

		//}
	}
}


void dbw_joystick_node::VehicleControlCOORCallback(const ace_msgs::VehicleControlCOOR& VehicleControlCOORholder)    
{
#ifdef ENABLE_VEHICLE_BEHAVIOR_NODE
	
	//mCood_SetVehSpeed = VehicleControlCOORholder.SetVehSpeed;
	//mCood_Vehicle_Speed_Auto_Enable = VehicleControlCOORholder.Vehicle_Speed_Auto_Enable;
	//mCood_Steer_Auto_Enable = VehicleControlCOORholder.Steer_Auto_Enable;
	//mCood_Brake_Auto_Enable = VehicleControlCOORholder.Brake_Auto_Enable;
	//mCood_SetBrakeReq = VehicleControlCOORholder.SetBrakeReq;

	
	
#endif
	mCood_Steer_Auto_Enable = VehicleControlCOORholder.Steer_Auto_Enable;
	//mCood_SteeringControlMaster = VehicleControlCOORholder.SteeringControlMaster;
	
	
}

void dbw_joystick_node::initializeServices()
{
    ROS_INFO("Initializing Services");
}

void dbw_joystick_node::initializePublishers()
{
    ROS_INFO("Initializing Publishers");
    VehicleContorlPublisher_ = nh_.advertise<ace_msgs::VehicleControl>("/VehicleControlCommand", 1, true);
}

float dbw_joystick_node::map(float x, float in_min, float in_max, float out_min, float out_max)
{
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

float dbw_joystick_node::convert_trans_rot_vel_to_steering_angle( float omega){
	if(omega == 0 || current_vehicle_speed == 0)
		return 0;
	else 
		return ( atan((wheelbase*omega)/(current_vehicle_speed*0.277)) );
}

void dbw_joystick_node::SteeringInfoCallback(const ace_msgs::SteeringInfo &Steering_Info_Holder)  {

   SteeringINFO_VARIABLE = Steering_Info_Holder;

	if(SteeringINFO_VARIABLE.SteeringAngleDirection)
		SignedAngle = -1 * SteeringINFO_VARIABLE.SteeringAngleFb;
	else
		SignedAngle = SteeringINFO_VARIABLE.SteeringAngleFb;
}

void dbw_joystick_node::joyCallback(const sensor_msgs::Joy &joy_holder)  {

        if (Control_Status || joy_holder.buttons[7] ){
            Control_Status = true;
			steering_actuator_level = -joy_holder.axes[0];
			throttle_actuator_level = map(joy_holder.axes[5], 1, -1, 0, 1);       // 1     to -1
			
		}


	    if (joy_holder.buttons[6]){
			Control_Status = false;
			steering_actuator_level = 0;
			throttle_actuator_level = 0;       // 1     to -1
			torquebasedsteerFunction();
		}
			//throttle_hex.input = throttle_actuator_level;

			float break_actuator_level = map(joy_holder.axes[2], 1, -1, 0, 1); //  1 to -1

			if (speed_level > 3)
				speed_level = 3;
			else if (speed_level < 0)
				speed_level = 0;
			
		CurTimeval = ros::Time::now();
	
			if(Control_Status )
			//	if((CurTimeval.sec - PrevTimeval.sec)>1)
			{
				
					PrevTimeval = ros::Time::now();

					
					//mCood_Brake_Auto_Enable = true;
					//mCood_SetBrakeReq = 0;
					//mCood_SteeringControlMaster = true;
					//mCood_Vehicle_Speed_Auto_Enable = true;	
					
					AcceptNewRequest = true;	
					mCood_SetVehSpeed = throttle_actuator_level*10;
					Requested_Steer_Angle = steering_actuator_level*(360);
					ROS_INFO ("JOY:::  Prev Req Error:%f(%d)",SignedAngle,Requested_Steer_Angle);

					//Requested_Steer_Angle = steering_actuator_level*(-2.0);
					torquebasedsteerFunction();

			}
	

}

void dbw_joystick_node::cmdvelCallback(const geometry_msgs::Twist &cmdvel_holder)   {
	//Only send +ve values
	if(cmdvel_holder.linear.x>=0)
		throttle_actuator_level= cmdvel_holder.linear.x;
	steering_actuator_level=cmdvel_holder.angular.z;

	CurTimeval = ros::Time::now();
	
	
			PrevTimeval = ros::Time::now();

			
			//mCood_Brake_Auto_Enable = true;
			//mCood_SetBrakeReq = 0;
			//mCood_SteeringControlMaster = false;
			//mCood_Vehicle_Speed_Auto_Enable = true;	
			AcceptNewRequest = true;	
			mCood_SetVehSpeed = throttle_actuator_level*5.00000000000;
			Requested_Steer_Angle = steering_actuator_level*(-2.5);
			ROS_INFO ("CMD_VEL:::Prev Req Error:%f(%f)",SignedAngle,Requested_Steer_Angle);
  
	torquebasedsteerFunction();

}



void dbw_joystick_node::resetPIDVariables(){

	InitialPos_Steer_Angle = SteeringINFO_VARIABLE.SteeringAngleFb;
	Prev_error_factor = DEFAULT_PREV_ERROR_VAL;

	Torque_steps = 19;
	Torque_offset = 0;
	Torque_sufficient = false;
	index_tor = 0;
	Request_Angle_achieved = false;

	Max_step_size = 20;
	Torque_map[0] = 0;
	Torque_map[1] = 0;
	Turn_Right = true;

	KP = 0;
	KI = 0;
	KD = 0;
	KD_Slope = 0;
	PID_factor = 0;
	Prev_steering_hex = 0;
	Error_factor = 1;
	ErroratStart = 1;
	correction_ctr = 0;

}

void dbw_joystick_node::torquebasedsteerFunction()  {
	static int dbg_Printctr = 0;
	int DeltaAngle;

	if(AcceptNewRequest)
	{
		resetPIDVariables();
		dbg_Printctr = 0;
		DeltaAngle = 0;

		//ROS_INFO("New Requested Angle = %d,Present Steering Angle=%f,%f	\n",Requested_Steer_Angle,SteeringINFO_VARIABLE.SteeringAngleFb,SteeringINFO_VARIABLE.SteeringAngleDirection);

	if ((!SteeringINFO_VARIABLE.SteeringAngleDirection) && (Requested_Steer_Angle>=0))
		DeltaAngle = ABS_DIFF(ABS_DIFF(Requested_Steer_Angle,0),SteeringINFO_VARIABLE.SteeringAngleFb); 
	else if ((SteeringINFO_VARIABLE.SteeringAngleDirection) && (Requested_Steer_Angle<0))
		DeltaAngle = ABS_DIFF(ABS_DIFF(Requested_Steer_Angle,0),SteeringINFO_VARIABLE.SteeringAngleFb); 
	else
		DeltaAngle = ABS_DIFF(Requested_Steer_Angle,0)+ SteeringINFO_VARIABLE.SteeringAngleFb; 


		//if(ABS_DIFF(ABS_DIFF(Requested_Steer_Angle,0),SteeringINFO_VARIABLE.SteeringAngleFb)>=80)
		if(DeltaAngle>=80)
		{
			ROS_INFO("Tuning value >80 BAND4\n");
			Counter_torque_point = 10;
			Tuning_val_band = BAND4;
		}else if(DeltaAngle>=45)
		{
			ROS_INFO("Tuning value >45 BAND3\n");
			Counter_torque_point = 10;
			Tuning_val_band = BAND3;
		}
		else if(DeltaAngle>=20)
		{
			ROS_INFO("Tuning value>20 BAND2\n");
			Counter_torque_point = 5;
			Tuning_val_band = BAND2;
		}
		else if(DeltaAngle>=15)
		{
			ROS_INFO("Tuning value>15 BAND1\n");
			Counter_torque_point = 5;
			Tuning_val_band = BAND1;
		}
		else
		{
			ROS_INFO("Tuning value<15 BAND0\n");
			Counter_torque_point = 3;
			Tuning_val_band = BAND0;
		}


	}
	else
	{

//    	ROS_INFO("Prev Requested Angle = %d,Present Steering Angle,direction=%f,%d	\n",Requested_Steer_Angle,SteeringINFO_VARIABLE.SteeringAngleFb,Steering_direction_bool.data);
	}



	if(0 == Requested_Steer_Angle)
		Control_Steer = false;
	else
		Control_Steer = true;



	#ifdef OPERATE_ONLY_RIGHT
		Error_factor = (SteeringINFO_VARIABLE.SteeringAngleFb - Requested_Steer_Angle);
	#else
		if(0 == SteeringINFO_VARIABLE.SteeringAngleDirection)
			Error_factor = (SteeringINFO_VARIABLE.SteeringAngleFb - Requested_Steer_Angle); //Right Turn
		else
			Error_factor = (-1*SteeringINFO_VARIABLE.SteeringAngleFb) - Requested_Steer_Angle; //Left Turn
	#endif


	if(AcceptNewRequest)
	{
		if (Error_factor>0)
		{
			Turn_Right = false;
			Error_factor = Error_factor*-1;
		}
		else
		{
			Turn_Right = true;
		}
		AcceptNewRequest = false;
		ErroratStart = Error_factor;


		if(SteeringINFO_VARIABLE.SteeringAngleFb>1)
		{
			if((0 == SteeringINFO_VARIABLE.SteeringAngleDirection) && (Turn_Right))
			{
				Turn_direction = Rforward;
			}
			//steering is right but turning left
			else if((0 == SteeringINFO_VARIABLE.SteeringAngleDirection) && (!Turn_Right))
			{
				Turn_direction = Rreverse;
			}
			else if((1 == SteeringINFO_VARIABLE.SteeringAngleDirection) && (!Turn_Right))
			{
				Turn_direction = Lforward;
			}
			else//steering is left but turning right
			{
				Turn_direction = Lreverse;
			}
		}
		else
		{
			if(Turn_Right)
			{
				Turn_direction = Rforward;
			}
			else 
			{
				Turn_direction = Lforward;
			}
		}


		if( ((Turn_direction == Rreverse)&&(Requested_Steer_Angle<0)) ||
			((Turn_direction == Lreverse)&&(Requested_Steer_Angle>0)) )
		{
			if(	BAND0 == Tuning_val_band)
				torque_zerocrossover = 7;
			else if(BAND1 == Tuning_val_band)
				torque_zerocrossover = 7;
			else if(BAND2 == Tuning_val_band)
				torque_zerocrossover = 7;
			else if(BAND3 == Tuning_val_band)
				torque_zerocrossover = 7;
			else
				torque_zerocrossover = 10;
		}
		else
		{	
			torque_zerocrossover = 0;
		}
		
		ROS_INFO("Turn_direction:%d,ZeroCross-torque:%d",Turn_direction,torque_zerocrossover);

	}
	else
	{
		if (Error_factor>0)
		{	
			Error_factor = Error_factor*-1;	
		}
	}

	//Over-achieved the requested angle
	//if(Error_factor < (Prev_error_factor-5))
	if(((Turn_direction==Rforward)&&(SignedAngle > Requested_Steer_Angle)) ||
	   ((Turn_direction==Rreverse)&&(SignedAngle < Requested_Steer_Angle)) ||
	   ((Turn_direction==Lforward)&&(SignedAngle < Requested_Steer_Angle))||
	   ((Turn_direction==Lreverse)&&(SignedAngle > Requested_Steer_Angle)) )
	{

		if(!AcceptNewRequest)
		{
			Request_Angle_achieved = true;
			//ROS_INFO("Request_Angle_achieved @ angle cross overpoint");			
		}
	}


	if(Control_Steer)
	{

		if(1)
		{

			if((Error_factor < (-1*Counter_torque_point))&&(!Request_Angle_achieved))
			{

				if(BAND4 == Tuning_val_band )
				{
					if(Turn_direction==Rforward)
					{
						KP = 10+ (8.3*Error_factor)/ErroratStart;
					}
					//steering is right but turning left
					else if(Turn_direction==Rreverse)
					{
						KP = 10+ (6.5*Error_factor)/ErroratStart;
					}				
					else if(Turn_direction==Lforward)
					{
						KP = 10+ (7.3*Error_factor)/ErroratStart;
					}
					else//steering is left but turning right
					{
						KP = 10+ (3.0*Error_factor)/ErroratStart;
					}				
				}
				else if(BAND3 == Tuning_val_band )
				{
					if(Turn_direction==Rforward)
					{
						KP = 10+ (7.9*Error_factor)/ErroratStart;
					}
					//steering is right but turning left
					else if(Turn_direction==Rreverse)
					{
						KP = 10+ (5.8*Error_factor)/ErroratStart;
					}				
					else if(Turn_direction==Lforward)
					{
						KP = 10+ (7.3*Error_factor)/ErroratStart;
					}
					else//steering is left but turning right
					{
						KP = 10+ (3.8*Error_factor)/ErroratStart;
					}				
				}
				else if(BAND2== Tuning_val_band)
				{
					if(Turn_direction==Rforward)
					{
						KP = 10+ (7.5*Error_factor)/ErroratStart;
					}
					//steering is right but turning left
					else if(Turn_direction==Rreverse)
					{
						KP = 10+ (6.3*Error_factor)/ErroratStart;
					}				
					else if(Turn_direction==Lforward)
					{
						KP = 10+ (7.2*Error_factor)/ErroratStart;
					}
					else//steering is left but turning right
					{
						KP = 10+ (2.1*Error_factor)/ErroratStart;
					}				
				}
				else if(BAND1== Tuning_val_band)
				{
					if(Turn_direction==Rforward)
					{
						KP = 10+ (5.0*Error_factor)/ErroratStart;
					}
					//steering is right but turning left
					else if(Turn_direction==Rreverse)
					{
						KP = 10+ (7.1*Error_factor)/ErroratStart;
					}				
					else if(Turn_direction==Lforward)
					{
						KP = 10+ (6.1*Error_factor)/ErroratStart;
					}
					else//steering is left but turning right
					{
						KP = 10+ (3.3*Error_factor)/ErroratStart;
					}
				}
				else
				{
					if(Turn_direction==Rforward)
					{
						KP = 10+ (4.5*Error_factor)/ErroratStart;
					}
					//steering is right but turning left
					else if(Turn_direction==Rreverse)
					{
						KP = 3+ (2.1*Error_factor)/ErroratStart;
					}				
					else if(Turn_direction==Lforward)
					{
						KP = 10+ (3.5*Error_factor)/ErroratStart;
					}
					else//steering is left but turning right
					{
						KP = 5+ (2.1*Error_factor)/ErroratStart;
					}

				}


				if(BAND4 == Tuning_val_band )
				{
					if(Turn_direction==Rforward)
						KI = KI + (-1*Error_factor)*0.2; //Summation of the previous errors
					//steering is right but turning left
					else if(Turn_direction==Rreverse)
						KI = KI + (-1*Error_factor)*0.2; //Summation of the previous errors

					else if(Turn_direction==Lforward)
						KI = KI + (-1*Error_factor)*0.2; //Summation of the previous errors

					else//steering is left but turning right
						KI = KI + (-1*Error_factor)*0.2; //Summation of the previous errors

				}
				else if(BAND3 == Tuning_val_band )
				{
					if(Turn_direction==Rforward)
						KI = KI + (-1*Error_factor)*0.2; //Summation of the previous errors
					//steering is right but turning left
					else if(Turn_direction==Rreverse)
						KI = KI + (-1*Error_factor)*0.2; //Summation of the previous errors

					else if(Turn_direction==Lforward)
						KI = KI + (-1*Error_factor)*0.2; //Summation of the previous errors

					else//steering is left but turning right
						KI = KI + (-1*Error_factor)*0.2; //Summation of the previous errors

				}
				else if(BAND2== Tuning_val_band)
				{
					if(Turn_direction==Rforward)
						KI = KI + (-1*Error_factor)*0.4; //Summation of the previous errors
					//steering is right but turning left
					else if(Turn_direction==Rreverse)
						KI = KI + (-1*Error_factor)*0.4; //Summation of the previous errors

					else if(Turn_direction==Lforward)
						KI = KI + (-1*Error_factor)*0.6; //Summation of the previous errors

					else//steering is left but turning right
						KI = KI + (-1*Error_factor)*0.6; //Summation of the previous errors
				}
				else if(BAND1== Tuning_val_band)
				{
					if(Turn_direction==Rforward)
						KI = KI + (-1*Error_factor)*2.5; //Summation of the previous errors
					//steering is right but turning left
					else if(Turn_direction==Rreverse)
						KI = KI + (-1*Error_factor)*1.5; //Summation of the previous errors

					else if(Turn_direction==Lforward)
						KI = KI + (-1*Error_factor)*1.2; //Summation of the previous errors

					else//steering is left but turning right
						KI = KI + (-1*Error_factor)*1.1; //Summation of the previous errors
				}
				else
				{
					if(Turn_direction==Rforward)
						KI = KI + (-1*Error_factor)*4.0; //Summation of the previous errors
					//steering is right but turning left
					else if(Turn_direction==Rreverse)
						KI = KI + (-1*Error_factor)*2.5; //Summation of the previous errors

					else if(Turn_direction==Lforward)
						KI = KI + (-1*Error_factor)*1.0; //Summation of the previous errors

					else//steering is left but turning right
						KI = KI + (-1*Error_factor)*2.5; //Summation of the previous errors
				}



				if(BAND4 == Tuning_val_band )
				{
					if(KI>60)
						KI = 3;
				}
				if(BAND3 == Tuning_val_band )
				{
					if(KI>60)
						KI = 3;
				}
				else if(BAND2 == Tuning_val_band)
				{
					if(KI>60)
						KI = 3;
				}
				else if(BAND1 == Tuning_val_band)
				{
					if(KI>140)
						KI = 20;
				}
				else
				{
					if(KI>140)
						KI = 20;
				}


				//if((DEFAULT_PREV_ERROR_VAL == Prev_error_factor)||(Error_factor<Prev_error_factor))
				if(DEFAULT_PREV_ERROR_VAL == Prev_error_factor)
					KD_Slope = 1;
				else
					KD_Slope = Error_factor - Prev_error_factor;

				if(Error_factor == ErroratStart)
				{
					if(Turn_direction==Rforward)
					{
						KP = 13; KI=0; KD=0;
					}
					//steering is right but turning left
					else if(Turn_direction==Rreverse)
					{
						KP = torque_zerocrossover+3; KI=0; KD=0;
					}				
					else if(Turn_direction==Lforward)
					{
						KP = 10; KI=0; KD=0;
					} 
					else//steering is left but turning right
					{
						KP = torque_zerocrossover+2; KI=0; KD=0;
					}			
					ErroratStart = ErroratStart - 2;		
				}

				PID_factor = KI-KD;
				Steering_Send_Status = true;

				if(Turn_Right)
					steering_hex =  DEC_VALUE_ZERO_NM_STEER - (CONST_STEP_SIZE*(int)KP) +PID_factor;
				else
					steering_hex = DEC_VALUE_ZERO_NM_STEER + (CONST_STEP_SIZE*(int)KP) -PID_factor;



//				ROS_INFO("D-Ang,EF,PEF,KP,KI,KD,I-D,Hex:%1.0f-%1.0f ,%d,%d,%1.1f,%1.1f,%1.1f,%d,%d\n",SteeringINFO_VARIABLE.SteeringAngleDirection,SteeringINFO_VARIABLE.SteeringAngleFb,Error_factor,Prev_error_factor,KP, KI, KD,PID_factor,steering_hex);

			}
			else
			{				
				#ifdef OPERATE_ONLY_RIGHT
					steering_hex = (DEC_VALUE_ZERO_NM_STEER - HOLD_STEERING_POS_OFFSET) ;
					Steering_Send_Status = true;
				#else

					if(SteeringINFO_VARIABLE.SteeringAngleFb>5)
					{
					
						if(!SteeringINFO_VARIABLE.SteeringAngleDirection)
						{
							steering_hex = (DEC_VALUE_ZERO_NM_STEER - HOLD_STEERING_POS_OFFSET) ;
						}
						else
						{
							steering_hex = (DEC_VALUE_ZERO_NM_STEER + HOLD_STEERING_POS_OFFSET) ;
						}
						Steering_Send_Status = true;
					}
					else
					{
						Control_Steer = false; //Auto centre
					}
				#endif

		if(dbg_Printctr < 3){
			dbg_Printctr = dbg_Printctr+1;
	//		ROS_INFO("Achieved!-D-Ang,EF,PEF,KP,KI,KD,I-D,Hex:%1.0f-%1.0f ,%d,%d,%d	\n",SteeringINFO_VARIABLE.SteeringAngleDirection,SteeringINFO_VARIABLE.SteeringAngleFb,Error_factor,Prev_error_factor,steering_hex);
		}

		Request_Angle_achieved = true;


			}
		}

	}

	Prev_error_factor = Error_factor;
	Prev_steering_hex = steering_hex;
	
	if(steering_hex > UPPER_LIMIT_TORQ)
	{
		ROS_INFO("Steering Torque CAN command is out of limits:%d\n",steering_hex	);
		steering_hex = 1230;
		Torque_steps = 10;
		Torque_offset = 0;
	}
	else if (steering_hex<LOWER_LIMIT_TORQ)
	{
		ROS_INFO("Steering Torque CAN command is out of limits:%d\n",steering_hex	);
		steering_hex = 833;
		Torque_steps = 10;
		Torque_offset = 0;
	}
	
	//ROS_INFO("Steering Torque value:%d\n",((int)(steering_hex*0.0078125-8)));

	//Steering ratio 15:1
	float calc_steering_angle = steering_hex;
	float corrected_steering_angle = convert_trans_rot_vel_to_steering_angle(calc_steering_angle)/15; 
	
	VehicleCONTROL_VARIABLE.ROS_Brake_Auto_Enable = Autoswitch_Status;
	VehicleCONTROL_VARIABLE.ROS_SetBrakeReq = mCood_SetBrakeReq;
	
	VehicleCONTROL_VARIABLE.ROS_SetVehSpeed = mCood_SetVehSpeed;
	VehicleCONTROL_VARIABLE.ROS_Steer_Auto_Enable = 1;// mCood_Steer_Auto_Enable;
	VehicleCONTROL_VARIABLE.ROS_SteeringControlMaster = Autoswitch_Status	;
	VehicleCONTROL_VARIABLE.ROS_SteeringTorqueMode = Autoswitch_Status ;
	//VehicleCONTROL_VARIABLE.ROS_SteeringTorqueReq = ((corrected_steering_angle*0.0078125)-8);
	//VehicleCONTROL_VARIABLE.ROS_SteeringTorqueReq = ((steering_hex*0.0078125)-8);
	VehicleCONTROL_VARIABLE.ROS_SteeringTorqueReq = Requested_Steer_Angle;
	VehicleCONTROL_VARIABLE.ROS_SteeringTorqueValidity = Autoswitch_Status;
	VehicleCONTROL_VARIABLE.ROS_Vehicle_Speed_Auto_Enable = Autoswitch_Status;

	VehicleContorlPublisher_.publish(VehicleCONTROL_VARIABLE);
}





int main(int argc, char** argv)
{
    // ROS set-ups:
    ros::init(argc, argv, "socketcan_driveby_wire_ROS_node"); //node name
    ros::NodeHandle nh("") ,nh_param("~"); // create a node handle; need to pass this to the class constructor

    ROS_INFO("main: instantiating an object of type ExampleRosClass");
    dbw_joystick_node DriveByWire(&nh);  //instantiate an ExampleRosClass object and pass in pointer to nodehandle for constructor to use
    ROS_INFO("main: going into spin; let the callbacks do all the work");
    ros::Rate loop_rate(20);
    while (ros::ok())
    {
        ros::spinOnce();
        loop_rate.sleep();
    }
    return 0;
}
