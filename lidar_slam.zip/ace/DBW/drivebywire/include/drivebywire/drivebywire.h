
#ifndef EXAMPLE_ROS_CLASS_H_
#define EXAMPLE_ROS_CLASS_H_

//some generically useful stuff to include...
#include <math.h>
#include <stdlib.h>
#include <string>
#include <vector>
#include <cmath>
#include <ros/ros.h> //ALWAYS need to include this
#include <can_msgs/Frame.h>
#include <sensor_msgs/Joy.h>
#include<geometry_msgs/Twist.h>
#include <ackermann_msgs/AckermannDrive.h>
#include <ackermann_msgs/AckermannDriveStamped.h>
#include <ace_msgs/SteeringInfo.h>
#include <ace_msgs/VehicleControl.h>
#include <ace_msgs/VehicleControlCOOR.h>
#include <ace_msgs/VehicleInfo.h>

//message types used in this example code;  include more message types, as needed
#include <std_msgs/Bool.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Int32.h>
#include <stdio.h>
#include <iostream>


typedef enum SPIDTuneband {BAND0=0, BAND1,BAND2,BAND3,BAND4} eSPIDTuneband;
typedef enum SetTurnDirection {Rforward=0, Rreverse,Lforward,Lreverse} eSetTurndirection;

//SOCKETCAN LIBRARIES



//Socket can conversions
#include <bitset>

//#include "socketcan.h"

// define a class, including a constructor, member variables and member functions
class dbw_joystick_node
{
public:
    dbw_joystick_node(ros::NodeHandle* nodehandle ); //"main" will need to instantiate a ROS nodehandle, then pass it to the constructor

    // may choose to define public methods or public variables, if desired
private:
    // put private member data here;  "private" data will only be available to member functions of this class;
    ros::NodeHandle nh_,nh_param; // we will need this, to pass between "main" and constructor

    ros::Subscriber steering_angle_sub_;
    ros::Subscriber joy_sub_;
    ros::Subscriber cmdvel_sub_;
    ros::Subscriber steer_req_sub_;
	ros::Subscriber VehicleControlCOOR_sub_;
	ros::Subscriber steeringinfo_sub_;
	ros::Subscriber VehicleInfo_sub_;

    ros::Publisher  VehicleContorlPublisher_;


   	ros::Publisher steering_hex_PID_pub;
   	ros::Publisher steering_hex_pub;
   	ros::Publisher steering_angle_pub;
   	ros::Publisher steering_direction_pub;
   	ros::Publisher steering_error_pub;
	ros::Time	PrevTimeval;
	ros::Time	CurTimeval;


    double val_from_subscriber_; //example member variable: better than using globals; convenient way to pass data from a subscriber to other member functions
    double val_to_remember_; // member variables will retain their values even as callbacks come and go
    int speed_level;

    //Subscriber variables
    ace_msgs::SteeringInfo SteeringINFO_VARIABLE;

    float steering_hex_Inte_old;
    float steering_hex_Diff_old;
    float steering_hex_PID;
    float steering_hex_prap, steering_hex_Inte,steering_hex_Diff;

    float mCood_Brake_Auto_Enable;
	float mCood_SetBrakeReq;
	float mCood_SetVehSpeed;
	float mCood_Steer_Auto_Enable;
	float mCood_SteeringControlMaster;
	float mCood_Vehicle_Speed_Auto_Enable;

    //Publisher variables
    ace_msgs::VehicleControl VehicleCONTROL_VARIABLE;

    double KP;
    double KI;
    double KD;
    double cumError;
    double rateError;
    double lastError;
    double error;
    // member methods as well:
    void initializeSubscribers(); // we will define some helper methods to encapsulate the gory details of initializing subscribers, publishers and services
    void initializePublishers();
    void initializeServices();
	void initializeVariables();
    
    
    void torquebasedsteerFunction();

    //prototype for callback of example subscriber
    
    void steering_angleCallback(const std_msgs::Float32& message_holder);
    
     
    void joyCallback(const sensor_msgs::Joy& joy_holder);
    
    void steerReqCallback(const std_msgs::Float32& SteerReq);
	void resetPIDVariables();
	void SteeringInfoCallback(const ace_msgs::SteeringInfo &Steering_Info_Holder);
    void VehicleControlCOORCallback(const ace_msgs::VehicleControlCOOR& VehicleControlCOORholder);
	void VehicleInfoCallback(const ace_msgs::VehicleInfo& VehicleInfoholder);
    float convert_trans_rot_vel_to_steering_angle(float  omega);
    float current_vehicle_speed;
    float wheelbase;


    void ackermancmdvelCallback(const ackermann_msgs::AckermannDriveStamped& ackercmdvel_holder);
    void cmdvelCallback(const geometry_msgs::Twist& cmdvel_holder);
    float map(float x, float in_min, float in_max, float out_min, float out_max);
    union IntFloat {
        uint32_t i;
        float f;
    };



//hsm1owt - variables for Joystick angle inputs
    bool JoyStick_Press_Status;
	bool Steering_Send_Status;
    int  Requested_Steer_Angle;
    int  Prev_Steer_Angle;
	int  InitialPos_Steer_Angle;
	int  Torque_steps;
	int  Torque_offset;
	int  Error_factor;
	int  Prev_error_factor;
	bool Torque_sufficient;
	int  steering_hex;
	int  Var_step_size;
    int Torque_map[10];
	int index_tor;
	bool Request_Angle_achieved;
	int Max_step_size;
	int Counter_torque_point;
	int Padded_Counter_torque_point;
	bool AcceptNewRequest;
	bool Control_Steer;
	bool Turn_Right;
	int Prev_steering_hex;
	int PID_factor;
	int ErroratStart;
	eSPIDTuneband Tuning_val_band;
	eSetTurndirection Turn_direction;
	float SignedAngle;
	int KD_Slope;
	int correction_ctr;
	int Avg_steering_hex;
	int torque_zerocrossover;

    int Throttle_level;
    float throttle_actuator_level;
    float steering_actuator_level;

    bool Control_Status;
    bool Autoswitch_Status;
    bool last_Control_Status;
    std_msgs::Bool Steering_direction_bool;
    can_msgs::Frame frame;
	can_msgs::Frame frame_steering , input_frame, steering_error;
    std_msgs::Float32 Steering_hex ,Steering_hex_pid;
    double prev_time;




}; // note: a class definition requires a semicolon at the end of the definition

#endif  // this closes the header-include trick...ALWAYS need one of these to match #ifndef
