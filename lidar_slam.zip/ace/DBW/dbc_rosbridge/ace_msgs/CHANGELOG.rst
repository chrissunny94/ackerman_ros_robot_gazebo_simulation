^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package dbw_pacifica_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2018-04-16)
------------------
* Initial release
* Contributors: Ryan Borchert
