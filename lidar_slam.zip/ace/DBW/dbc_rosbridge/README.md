<a href=""><img src="https://connectedautomateddriving.eu/wp-content/uploads/2018/11/bosch-logo-300x300.jpg" align="center" width="190"></a>


##CAN decoder and Encoder with ROS interface .

This is a bunch of C++ code which will help in encoding and decoding Can frames by the use of a DBC file .

[Savvycan](https://www.savvycan.com/) , is a great opensource tool for handling DBC file format and CAN related tools from Linux platform








###Decode part
------------------------------------------------------
==***Published CAN message**s*==

|Topic name| Message type  |Who uses this ?|
|---------------|--------------------|-------------------- |
|/VehicleInfo| [ace_msgs/VehicleInfo](https://sourcecode.socialcoding.bosch.com/projects/LSAD/repos/dbc_rosbridge/browse/ace_msgs/msg/VehicleInfo.msg?at=refs%2Fheads%2Fdevelopment) | This puts out the vehicleInfo such as **Vehicle Speed** and** Autonomous Switch status **|
|/WheelInfo| [ace_msgs/WheelInfo](https://sourcecode.socialcoding.bosch.com/projects/LSAD/repos/dbc_rosbridge/browse/ace_msgs/msg/WheelInfo.msg?at=refs%2Fheads%2Fdevelopment) | This puts out wheel speed FL ,FR ,RL, RR|
|/VehicleDynamicsInfo| [ace_msgs/WheelInfo](https://sourcecode.socialcoding.bosch.com/projects/LSAD/repos/dbc_rosbridge/browse/ace_msgs/msg/VehicleDynamicsInfo.msg?at=refs%2Fheads%2Fdevelopment) | yaw rate , Longitudinal Acceleration , Lateral acceleration|
|/VehiclePositionInfo| [sensor_msgs/NavSatFix](http://docs.ros.org/melodic/api/sensor_msgs/html/msg/NavSatFix.html) | GPS Latitude , Longitude , Altitude|
|/SteeringInfo| [ace_msg/SteeringInfo](https://sourcecode.socialcoding.bosch.com/projects/LSAD/repos/dbc_rosbridge/browse/ace_msgs/msg/SteeringInfo.msg?at=refs%2Fheads%2Fdevelopment) | SteeringAngleFb|
|/RadarInfo| [ace_msg/RadarInfo](https://sourcecode.socialcoding.bosch.com/projects/LSAD/repos/dbc_rosbridge/browse/ace_msgs/msg/RadarInfo.msg?at=refs%2Fheads%2Fdevelopment) | PObj0_Longitudinal PObj0_Lateral Radar_AccelerationRequest|
|/USS_Object_Array| [ace_msg/USS_object_array](https://sourcecode.socialcoding.bosch.com/projects/LSAD/repos/dbc_rosbridge/browse/ace_msgs/msg/USS_object_array.msg?at=development) | [ace_msgs/USS_object](https://sourcecode.socialcoding.bosch.com/projects/LSAD/repos/dbc_rosbridge/browse/ace_msgs/msg/USS_object.msg?at=development)|



==***Subscribed ROS topics***==

|Topic name| Message type  |Who gives this input  |
|---------------|--------------------|----------------------------|
|/can_rx| [can_msgs/Frame.msg](http://docs.ros.org/melodic/api/sensor_msgs/html/msg/Image.html) |Socketcan node |



###Encode part
------------------------------------------------------
==***Published CAN message**s*==

|Topic name| Message type  |Who uses this ?|
|---------------|--------------------|-------------------- |
|/can_tx| [can_msgs/Frame.msg](http://docs.ros.org/melodic/api/sensor_msgs/html/msg/Image.html) |Socketcan node for sending out to the vehicle bus|
|/172|Curtis , Throttle and break over CAN|
|/173|Steering control over CAN|


==***Subscribed ROS topics***==

|Topic name| Message type  |Who gives this input  |
|---------------|--------------------|----------------------------|
|/VehicleControlCommand| [ace_msgs/VehicleControl](https://sourcecode.socialcoding.bosch.com/projects/LSAD/repos/dbc_rosbridge/browse/ace_msgs/msg/VehicleControl.msg?at=refs%2Fheads%2Fdevelopment) |Steering angle , break and throttle level|
   





---------------------------------------------------------------------------------------------
## Contents

## Build Instructions

	catkin build dbc_rosbridge
	
OR

	catkin_make	
	
## Run instructions

	roslaunch dbc_rosbridge dbc_rosbridge.launch 


## How to push to SOCO

There is a small script kept at the root of the repo , **cd** into that directory and execute the following command 

	./sync_git.sh "I have made changes for module DBC"


Please pass the argument (a string) as a comment as to what changes you have done .



## Other userful CLI stuff

For your reference , the DBC file is stored in a folder called **DBC_FILES** , 
you can use [Savvycan](https://www.savvycan.com/) on Linux for viewing the DBC files .(*Editing is difficult on this software*)

	 candump can0 | cantools decode CURTIS_CAN.dbc
	
The above  command can decode the contents of the can0 using a .DBC file


[https://github.com/schutzwerk/CANalyzat0r](https://github.com/schutzwerk/CANalyzat0r) This Python based tool is a good alternative for peakView software , you can generate can_msgs and simulate everything without leaving your desk .


## Other usefull links


[https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet
](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet) 

[https://inside-docupedia.bosch.com/confluence/display/BIUNIV/How+to+Use+Git+and+Bitbucket](https://inside-docupedia.bosch.com/confluence/display/BIUNIV/How+to+Use+Git+and+Bitbucket) 


[https://inside-docupedia.bosch.com/confluence/display/LSADS/GIT+HG+social+coding](https://inside-docupedia.bosch.com/confluence/display/LSADS/GIT+HG+social+coding) 
