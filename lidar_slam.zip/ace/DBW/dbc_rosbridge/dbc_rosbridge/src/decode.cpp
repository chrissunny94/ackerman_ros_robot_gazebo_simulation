#include "ros/ros.h"
#include <sstream>
#include <dbc_rosbridge/decode.h>







/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Decode_Can_Msgs ::Decode_Can_Msgs(ros::NodeHandle *nodehandle) : n(*nodehandle) // constructor to declare the subcriber and publisher prototype
{   
    DEBUG_MODE = true;
    initializeDecode_Can_MsgsSubscribers();
    initializeDecode_Can_MsgsPublishers();
    initializeVariables();

}

void Decode_Can_Msgs ::initializeDecode_Can_MsgsPublishers() // definition of the Publishers
{
    

    publishVehicleInfo = n.advertise<ace_msgs::VehicleInfo>("VehicleInfo", 1, true);

    publishWheelInfo = n.advertise<ace_msgs::WheelInfo>("WheelInfo", 1, true);

    VehicleDynamicsInfo = n.advertise<ace_msgs::VehicleDynamicsInfo>("VehicleDynamicsInfo", 1, true);

    publishVehiclePositionInfo = n.advertise<sensor_msgs::NavSatFix>("VehiclePositionInfo", 1, true);

    publishSteeringInfo = n.advertise<ace_msgs::SteeringInfo>("SteeringInfo", 1, true);

    publishRadarInfo = n.advertise<ace_msgs::RadarInfo>("RadarInfo", 1, true);

    publishUSSObjects = n.advertise<ace_msgs::USS_object_array>("/USS_Object_Array", 1, true);

    if(DEBUG_MODE)
        ROS_INFO("Initialized Publishers succesfully");

}

void Decode_Can_Msgs ::initializeDecode_Can_MsgsSubscribers() // definition of the Subscribers
{
    Decode_Can_MsgsSub = n.subscribe("/can_rx", 1000, &Decode_Can_Msgs::Callback, this);

    if(DEBUG_MODE)
        ROS_INFO("Initialized Subscribers succesfully");
}

void Decode_Can_Msgs::initializeVariables(){
    v115.SteerAngEPASDir = v115.SteerAngEPASStatus = v115.SteeringAngle_Measured = 0;
    USS_OBJECT_ARRAY.Objects_List.reserve(20);
    ace_msgs::USS_object temp_USS;
    temp_USS.APointX = temp_USS.APointY = temp_USS.BPointX = temp_USS.BPointY = temp_USS.ExistProbability = temp_USS.ObjectHeight = temp_USS.ObjectType = 0;
    temp_USS.OOCStatus = 0;
    temp_USS.Object_ID =0 ;
    temp_USS.new_object = false;
    ROS_INFO("I AM HERE");
    for(int i =0 ;i<20; i++)
        USS_OBJECT_ARRAY.Objects_List.push_back(temp_USS);

    if(DEBUG_MODE)
        ROS_INFO("Initialized Veriables succesfully");

}

uint8_t *input(can_msgs::Frame &Decode_Can_MsgsData) // function for data input as an array per byte
{
    uint8_t *input_data_DO = new uint8_t[8];
    input_data_DO[0] = Decode_Can_MsgsData.data[0];
    input_data_DO[1] = Decode_Can_MsgsData.data[1];
    input_data_DO[2] = Decode_Can_MsgsData.data[2];
    input_data_DO[3] = Decode_Can_MsgsData.data[3];
    input_data_DO[4] = Decode_Can_MsgsData.data[4];
    input_data_DO[5] = Decode_Can_MsgsData.data[5];
    input_data_DO[6] = Decode_Can_MsgsData.data[6];
    input_data_DO[7] = Decode_Can_MsgsData.data[7];

    return input_data_DO;
}

void Decode_Can_Msgs::Callback(const can_msgs::Frame &DOframe) // callback function definition for publishing the messages
{
    DOData = DOframe;
    *input_data_DO = input(DOData);

   //id=0x63A

    if (DOframe.dlc == 8){
            if (DOData.id == 0x63A)
            {
                decode63A_type(*input_data_DO);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id63A.");
                publish_steering_info();
                
            }
            
            //id=0x115

            if (DOData.id == 0x115)
            {
                decode115_type(*input_data_DO);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id115.");
                publish_steering_info();
                
            }

            // id=0x122
            if (DOData.id == 0x122)
            {
                decode122_type(*input_data_DO);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id122.");
                publish_wheel_info();
                
            }

            // id=0x123
            if (DOData.id == 0x123)
            {
                decode123_type(*input_data_DO);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id123.");
                publish_wheel_info();
                
            }

            // id=0x125
            if (DOData.id == 0x125)
            {
                decode125_type(*input_data_DO);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id125.");
                publish_vehicle_info();
                
            }

            // id=0x130
            if (DOData.id == 0x130)
            {
                decode130_type(*input_data_DO);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id130.");
                publish_vehicle_dynamics_info();
                
            }

            // id=0x131
            if (DOData.id == 0x131)
            {
                decode131_type(*input_data_DO);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id131.");
                publish_vehicle_dynamics_info();
                
            }

            // id=0x132
            if (DOData.id == 0x132)
            {
                decode132_type(*input_data_DO);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id132.");
                publish_vehicle_info();
            
            }

            // id=0x133
            if (DOData.id == 0x133)
            {
                decode133_type(*input_data_DO);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id133.");
                publish_vehicle_position_info();
                
            }

            // id=0x134
            if (DOData.id == 0x134)
            {
                decode134_type(*input_data_DO);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id134.");
                publish_vehicle_position_info();
                
            }

            // id=0x135
            if (DOData.id == 0x135)
            {
                decode135_type(*input_data_DO);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id135.");
                publish_vehicle_position_info();
                
            }

            // id=0x1A1
            if (DOData.id == 0x1A1)
            {
                decode1A1_type(*input_data_DO);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id1A1.");
                publish_radar_info();
                
            }

            // id=0x602
            if (DOData.id == 0x602)
            {
                decodeUSS_type(*input_data_DO,0);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id602.");
                
            }

            // id=0x3F2
            if (DOData.id == 0x3F2)
            {
                decodeUSS_type(*input_data_DO,1);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id3F2.");
                
            }

            // id=0x3F3
            if (DOData.id == 0x3F3)
            {
                decodeUSS_type(*input_data_DO,2);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id3F3.");
                
            }

            // id=0x3F4
            if (DOData.id == 0x3F4)
            {
                decodeUSS_type(*input_data_DO,3);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id3F4.");
                
            }

            // id=0x3F5
            if (DOData.id == 0x3F5)
            {
                decodeUSS_type(*input_data_DO,4);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id3F5.");
                
            }

            // id=0x3F6
            if (DOData.id == 0x3F6)
            {
                decodeUSS_type(*input_data_DO,5);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id3F6.");
                
            }

            // id=0x3F7
            if (DOData.id == 0x3F7)
            {
                decodeUSS_type(*input_data_DO,6);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id3F7.");
                
            }

            // id=0x3F8
            if (DOData.id == 0x3F8)
            {
                decodeUSS_type(*input_data_DO,7);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id3F8.");
                
            }

            // id=0x3F9
            if (DOData.id == 0x3F9)
            {
                decodeUSS_type(*input_data_DO,8);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id3F9.");
            
            }

            // id=0x3FA
            if (DOData.id == 0x3FA)
            {
                decodeUSS_type(*input_data_DO,9);
                if(DEBUG_MODE)
                    ROS_INFO("Publishing message id3FA.");
            
            }

    }

    else
    {
        ROS_INFO("DLC , Ie Data Length Count of CAN frame !8");
    }
    

}


void Decode_Can_Msgs ::decode63A_type(uint8_t *data)
{
	uint16_t temp_val1,temp_val2,temp_val3; 

    v63A.SteerAngSpeed = decode(extractSignal(data, 8, 16, 1, 0), 0.125, -1500, 0);
    v63A.SteerAppliedTorque = decode(extractSignal(data, 24, 16, 1, 0), 0.0009765625, -8, 0);
} 

void Decode_Can_Msgs ::decode115_type(uint8_t *data)
{
    v115.SteerAngEPASDir = decode(extractSignal(data, 8, 1, 1, 0), 1, 0, 0);
    v115.SteeringAngle_Measured = decode(extractSignal(data, 9, 15, 1, 0), 0.04375, 0, 0);
    v115.SteerAngEPASStatus = decode(extractSignal(data, 16, 2, 1, 0), 1, 0, 0);
}

void Decode_Can_Msgs ::decode122_type(uint8_t *data)
{
    v122.ESC_FLWheelSpeedInvalid = decode(extractSignal(data, 8, 1, 1, 0), 1, 0, 0);
    v122.ESC_FLWheelDirection = decode(extractSignal(data, 9, 2, 1, 0), 1, 0, 0);
    v122.ESC_FLWheelSpeedKPH = decode(extractSignal(data, 11, 13, 1, 0), 0.05625, 0, 0);
    v122.ESC_FRWheelSpeedInvalid = decode(extractSignal(data, 24, 1, 1, 0), 1, 0, 0);
    v122.ESC_FRWheelDirection = decode(extractSignal(data, 25, 2, 1, 0), 1, 0, 0);
    v122.ESC_FRWheelSpeedKPH = decode(extractSignal(data, 27, 13, 1, 0), 0.05625, 0, 0);
    v122.ESC_Mcylinder_Pressure = decode(extractSignal(data, 32, 8, 1, 0), 1, 0, 0);
    v122.ESC_FrontWheelSpeedsKPH_AliveCou = decode(extractSignal(data, 48, 4, 1, 0), 1, 0, 0);
    v122.ESC_Mcylinder_PressureInvalid = decode(extractSignal(data, 52, 1, 1, 0), 1, 0, 0);
    v122.ESC_FrontWheelSpeedsKPH_CheckSum = decode(extractSignal(data, 56, 8, 1, 0), 1, 0, 0);
}

void Decode_Can_Msgs ::decode123_type(uint8_t *data)
{
    v123.ESC_RLWheelSpeedInvalid = decode(extractSignal(data, 8, 1, 1, 0), 1, 0, 0);
    v123.ESC_RLWheelDirection = decode(extractSignal(data, 9, 2, 1, 0), 1, 0, 0);
    v123.ESC_RLWheelSpeedKPH = decode(extractSignal(data, 11, 13, 1, 0), 0.05625, 0, 0);
    v123.ESC_RRWheelSpeedInvalid = decode(extractSignal(data, 24, 1, 1, 0), 1, 0, 0);
    v123.ESC_RRWheelDirection = decode(extractSignal(data, 25, 2, 1, 0), 1, 0, 0);
    v123.ESC_RRWheelSpeedKPH = decode(extractSignal(data, 27, 13, 1, 0), 0.05625, 0, 0);
    v123.ESC_RearWheelSpeedsKPH_AliveCou = decode(extractSignal(data, 48, 4, 1, 0), 1, 0, 0);
    v123.ESC_RearWheelSpeedsKPH_CheckSum = decode(extractSignal(data, 56, 8, 1, 0), 1, 0, 0);
}

void Decode_Can_Msgs ::decode125_type(uint8_t *data)
{
    v125.ESC_ABSActive = decode(extractSignal(data, 0, 1, 1, 0), 1, 0, 0);
    v125.ESC_BrakePedalSwitchStatus = decode(extractSignal(data, 1, 1, 1, 0), 1, 0, 0);
    v125.ESC_ESPActive = decode(extractSignal(data, 5, 1, 1, 0), 1, 0, 0);
    v125.ESC_PATAResponse = decode(extractSignal(data, 16, 1, 1, 0), 1, 0, 0);
    v125.ESC_VehicleSpeedInvalid = decode(extractSignal(data, 18, 1, 1, 0), 1, 0, 0);
    v125.ESC_VehicleSpeed = decode(extractSignal(data, 19, 13, 1, 0), 0.05625, 0, 0);
    v125.ESC_BrakePedalSwitchInvalid = decode(extractSignal(data, 30, 1, 1, 0), 1, 0, 0);
    v125.ESC_Status_AliveCounter = decode(extractSignal(data, 48, 4, 1, 0), 1, 0, 0);
    v125.ESC_Status_CheckSum = decode(extractSignal(data, 56, 8, 1, 0), 1, 0, 0);
}

void Decode_Can_Msgs ::decode130_type(uint8_t *data)
{
    v130.YRS1_CheckSum = decode(extractSignal(data, 0, 8, 1, 0), 1, 0, 0);
    v130.YRS_YawRateSensorState = decode(extractSignal(data, 9, 2, 1, 0), 1, 0, 0);
    v130.YRS_LateralSensorState = decode(extractSignal(data, 11, 2, 1, 0), 1, 0, 0);
    v130.YRS_LateralAcce = decode(extractSignal(data, 24, 16, 1, 0), 0.001, -2, 0);
    v130.YRS_YawRate = decode(extractSignal(data, 40, 16, 1, 0), 0.01, -180, 0);
    v130.YRS1_AliveCounter = decode(extractSignal(data, 56, 4, 1, 0), 1, 0, 0);

}

void Decode_Can_Msgs ::decode131_type(uint8_t *data)
{
    v131.YRS2_CheckSum = decode(extractSignal(data, 0, 8, 1, 0), 1, 0, 0);
    v131.YRS_LongitSensorState = decode(extractSignal(data, 14, 2, 1, 0), 1, 0, 0);
    v131.YRS_LongitlAcce = decode(extractSignal(data, 24, 16, 1, 0), 0.001, -2, 0);
    v131.YRS2_AliveCounter = decode(extractSignal(data, 56, 4, 1, 0), 1, 0, 0);

}

void Decode_Can_Msgs ::decode132_type(uint8_t *data)
{
    v132.BCU_AutnomusSwitch = decode(extractSignal(data, 0, 1, 1, 0), 1, 0, 0);
    v132.BCU_AutnomusSwitchValidity = decode(extractSignal(data, 1, 1, 1, 0), 1, 1, 0);
    v132.BCU_BrakeStatus = decode(extractSignal(data, 8, 1, 1, 0), 1, 0, 0);
    v132.BCU_BrakeStatusValidity = decode(extractSignal(data, 9, 1, 1, 0), 1, 0, 0);
    v132.BCU_Drivemode = decode(extractSignal(data, 16, 2, 1, 0), 1, 0, 0);
    v132.BCU_DrivemodeValidity = decode(extractSignal(data, 18, 1, 1, 0), 1, 0, 0);
    v132.BCU_LSAD_AliveCounter = decode(extractSignal(data, 48, 4, 1, 0), 1, 0, 0);
    v132.BCU_LSAD_Checksum = decode(extractSignal(data, 56, 8, 1, 0), 1, 0, 0);
    v132.BCU_forwardgearStatus = decode(extractSignal(data, 56, 8, 1, 0), 1, 0, 0);
}

void Decode_Can_Msgs ::decode133_type(uint8_t *data)
{
    v133.VMPS_GNSSLattitudeMsgCount = decode(extractSignal(data, 0, 8, 0, 0), 1, 0, 0);
    v133.VMPS_GNSSLattitudeVal = decode(extractSignal(data, 8, 8, 0, 0), 1, 0, 0);
    v133.VMPS_GNSSLattitude = decode(extractSignal(data, 16, 32, 0, 0), 0.0000001, -90, 0);
}

void Decode_Can_Msgs ::decode134_type(uint8_t *data)
{
    
    v134.VMPS_GNSSLongitudeMsgCount = decode(extractSignal(data, 0, 8, 0, 0), 1, 0, 0);
    v134.VMPS_GNSSLongitudeVal = decode(extractSignal(data, 8, 8, 0, 0), 1, 0, 0);
    v134.VMPS_GNSSLongitude = decode(extractSignal(data, 16, 32, 0, 0), 0.0000001, -180, 0);
}

void Decode_Can_Msgs ::decode135_type(uint8_t *data)
{
    v135.VMPS_GNSS_Lat_MsgCcnt = decode(extractSignal(data, 0, 8, 0, 0), 1, 0, 0);
    v135.VMPS_GNSS_Lat_Validity = decode(extractSignal(data, 8, 8, 0, 0), 1, 0, 0);
    v135.VMPS_GNSS_STD_DEV = decode(extractSignal(data, 16, 16, 0, 0), 0.01, 0, 0);
    v135.VMPS_GNSS_Height = decode(extractSignal(data, 32, 32, 0, 0), 0.0001, -500, 0);
}

void Decode_Can_Msgs ::decode1A1_type(uint8_t *data)
{
    v1A1.FRS_ALOD_axvCvAim = decode(extractSignal(data, 0, 8, 1, 0), 0.05, -7, 0);
    v1A1.FRS_ALOD_aDtUpperLimitAxvCv = decode(extractSignal(data, 8, 7, 1, 0), 0.2, 0, 0);
    v1A1.FRS_ALOD_DecToStopReq = decode(extractSignal(data, 15, 1, 1, 0), 1, 0, 0);
    v1A1.FRS_ALOD_AcceComfUpperValue = decode(extractSignal(data, 16, 8, 1, 0), 0.05, -7, 0);
    v1A1.FRS_ALOD_AcceComfLowerValue = decode(extractSignal(data, 24, 8, 1, 0), 0.05, -7, 0);
    v1A1.FRS_ALOD_StartRequest = decode(extractSignal(data, 32, 1, 1, 0), 1, 0, 0);
    v1A1.FRS_ALOD_StopForbid = decode(extractSignal(data, 33, 1, 1, 0), 1, 0, 0);
    v1A1.FRS_ALOD_Mode = decode(extractSignal(data, 36, 4, 1, 0), 1, 0, 0);
    v1A1.FRS_ALOD_AliveCounter = decode(extractSignal(data, 40, 4, 1, 0), 1, 1, 0);
    v1A1.FRS_ALOD_ShutdownMode = decode(extractSignal(data, 44, 2, 1, 0), 1, 0, 0);
    v1A1.FRS_ALOD_MinimumBraking = decode(extractSignal(data, 46, 1, 1, 0), 1, 0, 0);
    v1A1.FRS_ALOD_BrakePreferred = decode(extractSignal(data, 47, 1, 1, 0), 1, 0, 0);
    v1A1.FRS_ALOD_aDtLowerLimitAxvCv = decode(extractSignal(data, 48, 7, 1, 0), 0.2, 0, 0);
    //msg.FRS_ALOD_Decode_Can_MsgsReq = decode(extractSignal(data, 55, 1, 1, 0), 1, 0, 0);
    v1A1.FRS_ALOD_Checksum = decode(extractSignal(data, 56, 8, 1, 0), 1, 0, 0);
}

void Decode_Can_Msgs ::decodeUSS_type(uint8_t *data, uint count)
{   
    ace_msgs::USS_object temp_uss_object;

    temp_uss_object.APointX = decode(extractSignal(data, 0, 10, 0, 1), 1.5, 100, 1);
    temp_uss_object.APointY = decode(extractSignal(data, 10, 10, 0, 1), 1.5, 100, 1);
    temp_uss_object.BPointX = decode(extractSignal(data, 28, 10, 0, 1), 1.5, 100, 1);
    temp_uss_object.BPointY = decode(extractSignal(data, 38, 10, 0, 1), 1.5, 100, 1);
    temp_uss_object.ExistProbability = decode(extractSignal(data, 20, 4, 0, 0), 1, 0, 0);
    temp_uss_object.ObjectHeight = decode(extractSignal(data, 50, 2, 0, 0), 1, 0, 0);
    temp_uss_object.ObjectType = decode(extractSignal(data, 52, 3, 0, 0), 1, 0, 0);
    temp_uss_object.OOCStatus = decode(extractSignal(data, 24, 4, 0, 0), 1, 0, 0);
    temp_uss_object.new_object = true;

    //temp_uss_object.new_object = decode(extractSignal(data, 55, 1, 0, 0), 1, 0, 0);
    temp_uss_object.Object_ID = count;
    //temp_uss_object.Object_ID = decode(extractSignal(data, 56, 8, 0, 0), 1, 0, 0);

    bool multiplexed = decode(extractSignal(data, 48, 2, 0, 0), 1, 0, 0);
    USS_OBJECT_ARRAY.Objects_List.push_back(temp_uss_object);
    publishUSSObjects.publish(USS_OBJECT_ARRAY);

    // vUSS.sigSIP_MAP_01_1stPointX = 
    // vUSS.sigSIP_MAP_11_1stPointX = decode(extractSignal(data, 0, 10, 0, 1), 1.5, 100, 1);
    // vUSS.sigSIP_MAP_01_1stPointY = 
    // vUSS.sigSIP_MAP_11_1stPointY = decode(extractSignal(data, 10, 10, 0, 1), 1.5, 100, 1);
    // vUSS.sigSIP_MAP_01_ExistProbability = 
    // vUSS.sigSIP_MAP_11_ExistProbability = decode(extractSignal(data, 20, 4, 0, 0), 1, 0, 0);
    // vUSS.sigSIP_MAP_01_OOCStatus = 
    // vUSS.sigSIP_MAP_11_OOCStatus = decode(extractSignal(data, 24, 4, 0, 0), 1, 0, 0);
    // vUSS.sigSIP_MAP_01_2ndPointX = 
    // vUSS.sigSIP_MAP_11_2ndPointX = decode(extractSignal(data, 28, 10, 0, 1), 1.5, 100, 1);
    // vUSS.sigSIP_MAP_01_2ndPointY = 
    // vUSS.sigSIP_MAP_11_2ndPointY = decode(extractSignal(data, 38, 10, 0, 1), 1.5, 100, 1);
    // vUSS.Multiplex_ID_01 = 
    // vUSS.sigSIP_MAP_01_ObjectHeight = 
    // vUSS.sigSIP_MAP_11_ObjectHeight = decode(extractSignal(data, 50, 2, 0, 0), 1, 0, 0);
    // vUSS.sigSIP_MAP_01_ObjectType = 
    // vUSS.sigSIP_MAP_11_ObjectType = decode(extractSignal(data, 52, 3, 0, 0), 1, 0, 0);
    // vUSS.sigSIP_MAP_01_NewObj = 
    // vUSS.sigSIP_MAP_11_NewObj = decode(extractSignal(data, 55, 1, 0, 0), 1, 0, 0);
    // vUSS.sigSIP_MAP_01_Obj_ID = 
    // vUSS.sigSIP_MAP_11_Obj_ID = decode(extractSignal(data, 56, 8, 0, 0), 1, 0, 0);
}


////////////////////////////////////////////////////##############################################/////////////////////////////////////////////////////////////
void Decode_Can_Msgs::publish_vehicle_info()
{
    ace_msgs::VehicleInfo temp;

    temp.VehicleSpeed = v125.ESC_VehicleSpeed;
    temp.VehicleSpeedValidity = v125.ESC_VehicleSpeedInvalid;
    temp.BrakeStatus = v132.BCU_BrakeStatus;
    temp.BrakeStatusValidity = v132.BCU_BrakeStatusValidity;
    temp.AutoSwitchStatus = v132.BCU_AutnomusSwitch;
    temp.AutnomusSwitchValidity = v132.BCU_AutnomusSwitchValidity;
    temp.DriveMode = v132.BCU_Drivemode;
    temp.DrivemodeValidity = v132.BCU_DrivemodeValidity;

    publishVehicleInfo.publish(temp);
}

void Decode_Can_Msgs::publish_wheel_info()
{
    ace_msgs::WheelInfo temp;
    
    temp.FrontRight.WheelSpeed = v122.ESC_FRWheelSpeedKPH;
    temp.FrontRight.WheelDirection = v122.ESC_FRWheelDirection;
    temp.FrontRight.WheelSpeedInvalid = v122.ESC_FRWheelSpeedInvalid;
    temp.FrontLeft.WheelSpeed = v122.ESC_FLWheelSpeedKPH;
    temp.FrontLeft.WheelDirection = v122.ESC_FLWheelDirection;
    temp.FrontLeft.WheelSpeedInvalid = v122.ESC_FLWheelSpeedInvalid;
    temp.RearRight.WheelSpeed = v123.ESC_RRWheelSpeedKPH;
    temp.RearRight.WheelDirection = v123.ESC_RRWheelDirection;
    temp.RearRight.WheelSpeedInvalid = v123.ESC_RRWheelSpeedInvalid;
    temp.RearLeft.WheelSpeed = v123.ESC_RLWheelSpeedKPH;
    temp.RearLeft.WheelDirection = v123.ESC_RLWheelDirection;
    temp.RearLeft.WheelSpeedInvalid = v123.ESC_RLWheelSpeedInvalid;

    publishWheelInfo.publish(temp);
}

void Decode_Can_Msgs::publish_vehicle_dynamics_info()
{
    ace_msgs::VehicleDynamicsInfo temp;
    
    temp.YawRate = v130.YRS_YawRate;
    temp.LongitudinalAcceleration = v131.YRS_LongitlAcce;
    temp.LateralAcceleration = v130.YRS_LateralAcce;
    temp.LongAccValid = v131.YRS_LongitSensorState;
    temp.LatAccValid = v130.YRS_LateralSensorState;
    temp.YawRateValid = v130.YRS_YawRateSensorState;

    VehicleDynamicsInfo.publish(temp);
}

void Decode_Can_Msgs::publish_vehicle_position_info()
 {
     sensor_msgs::NavSatFix temp_fix;

     temp_fix.altitude = 0;
     temp_fix.latitude = v133.VMPS_GNSSLattitude;
     temp_fix.longitude = v134.VMPS_GNSSLongitude;
     temp_fix.altitude = v135.VMPS_GNSS_Height;
     temp_fix.position_covariance[0] = v135.VMPS_GNSS_STD_DEV*v135.VMPS_GNSS_STD_DEV;
     temp_fix.position_covariance[4] = v135.VMPS_GNSS_STD_DEV*v135.VMPS_GNSS_STD_DEV;
     temp_fix.position_covariance[8] = v135.VMPS_GNSS_STD_DEV*v135.VMPS_GNSS_STD_DEV;
     temp_fix.position_covariance_type = 1;
     temp_fix.header.stamp = ros::Time::now();
     temp_fix.header.frame_id = "vmps";
    
     
     publishVehiclePositionInfo.publish(temp_fix);
 }

 void Decode_Can_Msgs::publish_steering_info()
 {
     ace_msgs::SteeringInfo temp;

     

     temp.SteeringAngleDirection = v115.SteerAngEPASDir;
     temp.SteeringAngleFb = v115.SteeringAngle_Measured;
     temp.SteeringAngleFbValid = v115.SteerAngEPASStatus;
     temp.SteeringTorqueFb = v63A.SteerAppliedTorque;
     temp.SteeringAngleSpeed = v63A.SteerAngSpeed;

     publishSteeringInfo.publish(temp);
 }

void Decode_Can_Msgs::publish_radar_info()
 {
     ace_msgs::RadarInfo temp;

     temp.PObj0_Longitudinal = v1A1.FRS_ALOD_AcceComfLowerValue;
     temp.PObj0_Lateral = v1A1.FRS_ALOD_AcceComfUpperValue;
     temp.Radar_AccelerationRequest = v1A1.FRS_ALOD_axvCvAim;

     publishRadarInfo.publish(temp);
 }

int main(int argc, char **argv)
{

    ros::init(argc, argv, "decode");
    ros::NodeHandle n("");

    Decode_Can_Msgs r(&n);

    ros::Rate loop_rate(50);

    while (ros::ok())
    {
        ros::spinOnce();
        loop_rate.sleep();
    }
}

