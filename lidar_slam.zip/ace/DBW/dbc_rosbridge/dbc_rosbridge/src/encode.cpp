#include "ros/ros.h"
#include <sstream>

#include<dbc_rosbridge/encode.h>




#include <can_msgs/Frame.h>

#include <stdint.h> //uint typedefinitions, non-rtw!
#include <string.h>
#include <iostream>
using namespace std;
#define MASK64(nbits) ((0xffffffffffffffff) >> (64 - nbits))

// object for class ROS_CAN

uint8_t input_data[8];




Encode_CAN_Msg ::Encode_CAN_Msg(ros::NodeHandle *nodehandle) : n(*nodehandle) // constructor to declare the subcriber and publisher prototype
{
    initializeEncode_CAN_MsgSubscribers();
    initializeEncode_CAN_MsgPublishers();
}

void Encode_CAN_Msg::initializeEncode_CAN_MsgPublishers() // definition of the Publishers
{
    CANPublisher = n.advertise<can_msgs::Frame>("/can_tx", 1000, true);
    
}

void Encode_CAN_Msg ::initializeEncode_CAN_MsgSubscribers() // definition of the Subscribers
{
    SubscribeVehicleControl = n.subscribe("/VehicleControlCommand", 1000, &Encode_CAN_Msg::VehicleControlCallback, this);
}


void Encode_CAN_Msg::VehicleControlCallback(const ace_msgs::VehicleControl &VehicleControlDATA_temp) // callback function definition for publishing the messages
{   
    VehicleControlDATA = VehicleControlDATA_temp;
    sendCAN_Steering(VehicleControlDATA.ROS_SteeringTorqueReq);
    sendCAN_Throttle(VehicleControlDATA.ROS_SetVehSpeed);

}

float Encode_CAN_Msg::map(float x, float in_min, float in_max, float out_min, float out_max)
{
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}


void Encode_CAN_Msg::reset_BCU_Variables(){
    BCU.aCANdata8[0] = 0;
    BCU.aCANdata8[1] = 0;
    BCU.aCANdata8[2] = 0;
    BCU.aCANdata8[3] = 0;
    BCU.aCANdata8[4] = 0;
    BCU.aCANdata8[5] = 0;
    BCU.aCANdata8[6] = 0;
    BCU.aCANdata8[7] = 0;
    BCU.CANdata64 = 0;
}


void Encode_CAN_Msg::sendCAN_Steering(float torque_value){

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    reset_BCU_Variables();
    // getting the raw value by passing the physical value, offset and factor into an array element and then setting data into 64 bit using length and start position
    BCU.settingDataOntoCAN_1((uint8_t)PhysicalToRawConversion(VehicleControlDATA.ROS_SteeringControlMaster, 0, 1), 1, 7);
    BCU.settingDataOntoCAN_1((uint8_t)PhysicalToRawConversion(VehicleControlDATA.ROS_SteeringTorqueMode, 0, 1), 1, 39);
    BCU.settingDataOntoCAN_1(((uint16_t)PhysicalToRawConversion(torque_value, -8, 0.0078125) & 0x000F), 4, 44);
    BCU.settingDataOntoCAN_1((((uint16_t)PhysicalToRawConversion(torque_value, -8, 0.0078125) >> 4) & 0x007F), 7, 32);

    //converting 64 bit to 8 bit array elements
    BCU.Convert64To8arrays();
    // Publishing 173 msg
    frame.header.frame_id = "172";
    frame.header.stamp = ros::Time::now();
    frame.is_rtr = false;
    frame.is_extended = false;
    frame.is_error = false;
    frame.dlc = 8;
    frame.id = 0x172;

    frame.data[0] = BCU.aCANdata8[0];
    frame.data[1] = BCU.aCANdata8[1];
    frame.data[2] = BCU.aCANdata8[2];
    frame.data[3] = BCU.aCANdata8[3];
    frame.data[4] = BCU.aCANdata8[4];
    frame.data[5] = BCU.aCANdata8[5];
    frame.data[6] = BCU.aCANdata8[6];
    frame.data[7] = BCU.aCANdata8[7];
	
    CANPublisher.publish(frame); // publish


}

void Encode_CAN_Msg::sendCAN_Throttle(float vehicle_speed){
    //Publishing CURTIS msgs 173 for Throttle and Brake
    reset_BCU_Variables();
    // getting the raw value by passing the physical value, offset and factor into an array element and then setting data into 64 bit using length and start position
    int vehicle_speed_hex = map(vehicle_speed,-15,15,-32767,32767);
    BCU.settingDataOntoCAN_2((uint32_t)PhysicalToRawConversion(vehicle_speed, 0, 0.0003662), 16, 8);
    BCU.settingDataOntoCAN_2((float)PhysicalToRawConversion(VehicleControlDATA.ROS_SetBrakeReq, 0, 0.0003), 16, 32);

    //converting 64 bit to 8 bit array elements
    BCU.Convert64To8arrays();
    // Publishing 173 msg
    frame.header.frame_id = "173";
    frame.header.stamp = ros::Time::now();
    frame.is_rtr = false;
    frame.is_extended = false;
    frame.is_error = false;
    frame.dlc = 8;
    frame.id = 0x173;
    frame.data[0] = BCU.aCANdata8[0];
    frame.data[1] = BCU.aCANdata8[1];
    frame.data[2] = BCU.aCANdata8[2];
    frame.data[3] = BCU.aCANdata8[3];
    frame.data[4] = BCU.aCANdata8[4];
    frame.data[5] = BCU.aCANdata8[5];
    frame.data[6] = BCU.aCANdata8[6];
    frame.data[7] = BCU.aCANdata8[7];
    CANPublisher.publish(frame); // publish

}






int main(int argc, char **argv)
{

    ros::init(argc, argv, "encode");
    ros::NodeHandle n("");

    Encode_CAN_Msg r(&n);

    ros::Rate loop_rate(50);
	ROS_INFO("Encode running");
    while (ros::ok())
    {
        ros::spinOnce();
        loop_rate.sleep();
    }
}

