
#include <ros/ros.h> //ALWAYS need to include this
#include <can_msgs/Frame.h>

#include "ace_msgs/ID63A.h"
#include "ace_msgs/ID115.h"
#include "ace_msgs/ID122.h"
#include "ace_msgs/ID123.h"
#include "ace_msgs/ID125.h"
#include "ace_msgs/ID130.h"
#include "ace_msgs/ID131.h"
#include "ace_msgs/ID132.h"
#include "ace_msgs/ID133.h"
#include "ace_msgs/ID134.h"
#include "ace_msgs/ID135.h"
#include "ace_msgs/ID1A1.h"
#include "ace_msgs/IDUSS.h"

#include "ace_msgs/VehicleInfo.h"
#include "ace_msgs/WheelInfo.h"
#include "ace_msgs/RadarInfo.h"
#include "ace_msgs/SteeringInfo.h"
#include "ace_msgs/VehicleDynamicsInfo.h"
#include "ace_msgs/VehiclePositionInfo.h"

#include "ace_msgs/USS_object_array.h"
#include "ace_msgs/USS_object.h"
#include "sensor_msgs/NavSatFix.h"



#include <can_msgs/Frame.h>

#include <stdint.h> //uint typedefinitions, non-rtw!
#include <string.h>
#include <iostream>


//message types used in this example code;  include more message types, as needed


//SOCKETCAN LIBRARIES
#define MASK64(nbits) ((0xffffffffffffffff) >> (64 - nbits))


//Socket can conversions
#include <bitset>


// Keep this algorithm as it is. /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
uint64_t extractSignal(uint8_t *frame, const uint8_t startbit, const uint8_t length, bool is_big_endian, bool is_signed)
{
    uint8_t start_byte = startbit / 8;
    uint8_t startbit_in_byte = startbit % 8;
    uint8_t current_target_length = (8 - startbit_in_byte);
    uint8_t end_byte = 0;
    int8_t count = 0;

    // Write first bits to target
    uint64_t target = frame[start_byte] >> startbit_in_byte;

    //cout<<"current_target_length"<<current_target_length<<endl;

    // Write residual bytes
    if (is_big_endian) // Motorola (big endian)
    {
        end_byte = (start_byte * 8 + 8 - startbit_in_byte - length) / 8;

        for (count = start_byte - 1; count >= end_byte; count--)
        {
            target |= frame[count] << current_target_length;
            current_target_length += 8;
        }
    }


    else // Intel (little endian)
    {
        end_byte = (startbit + length) / 8;
        current_target_length = 0;
        target = 0;
        for (count = start_byte; count < end_byte; count++)
        {
            target |= frame[count] << current_target_length;
            current_target_length += 8;
        }
    }

    // else // Intel (little endian)
    // {
    //     end_byte = (startbit + length - 1) / 8;

    //     for (count = start_byte + 1; count <= end_byte; count++)
    //     {
    //         target |= frame[count] << current_target_length;
    //         current_target_length += 8;
    //     }
    // }

    target &= MASK64(length);

    // perform sign extension
    if (is_signed)
    {
        int64_t msb_sign_mask = 1 << (length - 1);
        target = ((int64_t)target ^ msb_sign_mask) - msb_sign_mask;
    }
    return target;
}

float decode(uint64_t target, float factor, float offset, bool is_signed)
{
    if (is_signed)
        return ((int64_t)target) * factor + offset;
    else
        return target * factor + offset;
}


// define a class, including a constructor, member variables and member functions
class Decode_Can_Msgs
{
public:
    Decode_Can_Msgs(ros::NodeHandle* nodehandle ); //"main" will need to instantiate a ROS nodehandle, then pass it to the constructor
    

    //Class variables
    ace_msgs::ID63A v63A; // variable for custom message type for id 0x63A
    ace_msgs::ID115 v115; // variable for custom message type for id 0x115
    ace_msgs::ID122 v122; // variable for custom message type for id 0x122
    ace_msgs::ID123 v123; // variable for custom message type for id 0x123
    ace_msgs::ID125 v125; // variable for custom message type for id 0x125
    ace_msgs::ID130 v130; // variable for custom message type for id 0x130
    ace_msgs::ID131 v131; // variable for custom message type for id 0x131
    ace_msgs::ID132 v132; // variable for custom message type for id 0x132
    ace_msgs::ID133 v133; // variable for custom message type for id 0x133
    ace_msgs::ID134 v134; // variable for custom message type for id 0x134
    ace_msgs::ID135 v135; // variable for custom message type for id 0x135
    ace_msgs::ID1A1 v1A1; // variable for custom message type for id 0x1A1
    ace_msgs::IDUSS vUSS; // variable for custom message type for id 0xUSS


    
    ace_msgs::USS_object_array USS_OBJECT_ARRAY;
    
    bool DEBUG_MODE;
    void initializeDecode_Can_MsgsSubscribers();
    void initializeDecode_Can_MsgsPublishers();
    void initializeVariables();
    

    ros::Publisher publishVehicleInfo , publishWheelInfo ,VehicleDynamicsInfo,publishVehiclePositionInfo ,publishSteeringInfo,publishRadarInfo, publishUSSObjects;

    ros::Subscriber Decode_Can_MsgsSub;
    uint8_t *input_data_DO[8];
    can_msgs::Frame DOData;

    
    void Callback(const can_msgs::Frame &DOframe); // the callback function

    // prototype for the decode fuction for taking the inputs
    void decode63A_type(uint8_t *data);
    void decode115_type(uint8_t *data);
    void decode122_type(uint8_t *data);
    void decode123_type(uint8_t *data);
    void decode125_type(uint8_t *data);
    void decode130_type(uint8_t *data);
    void decode131_type(uint8_t *data);
    void decode132_type(uint8_t *data);
    void decode133_type(uint8_t *data);
    void decode134_type(uint8_t *data);
    void decode135_type(uint8_t *data);
    void decode1A1_type(uint8_t *data);
    void decodeUSS_type(uint8_t *data ,uint count);
    

    //ROS PUBLISHERS
    void publish_vehicle_info();
    void publish_wheel_info();
    void publish_vehicle_dynamics_info();
    void publish_vehicle_position_info();
    void publish_steering_info();
    void publish_radar_info();


    // may choose to define public methods or public variables, if desired
    private:
    // put private member data here;  "private" data will only be available to member functions of this class;
    ros::NodeHandle n,nh_param; // we will need this, to pass between "main" and constructor
    


}; // note: a class definition requires a semicolon at the end of the definition


