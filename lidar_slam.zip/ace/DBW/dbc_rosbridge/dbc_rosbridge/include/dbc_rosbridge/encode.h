
#include <ros/ros.h> //ALWAYS need to include this
#include <can_msgs/Frame.h>


#include <ace_msgs/VehicleControl.h>


#include <can_msgs/Frame.h>

#include <stdint.h> //uint typedefinitions, non-rtw!
#include <string.h>
#include <iostream>


//message types used in this example code;  include more message types, as needed


//SOCKETCAN LIBRARIES



//Socket can conversions
#include <bitset>

//#include "socketcan.h"

// define a class, including a constructor, member variables and member functions

class ROS_CAN
{
public:
    uint8_t CANID;
    uint8_t aCANdata8[8];
    uint64_t CANdata64;

    void settingDataOntoCAN_1(uint8_t data, uint8_t Length, uint8_t startBitPos); // for setting CANdata size less or Equal to 8 bit

    void settingDataOntoCAN_2(uint16_t data, uint16_t Length, uint8_t startBitPos); // for setting CANdata size > 8 bit
	void settingDataOntoCAN_2_motorolla(uint16_t data, uint16_t Length, uint8_t startBitPos);
    uint8_t *GetCANData8(void);
    void Convert64To8arrays(void);
};

void ROS_CAN ::settingDataOntoCAN_1(uint8_t data, uint8_t Length, uint8_t startBitPos) // for setting CANdata size less or Equal to 8 bit
{
    uint64_t l_temp, mask;
    uint8_t i;
    for (i = 0; i < Length; i++)
    {
        mask = ((1 << i) | mask);
    }
    mask = (mask) << startBitPos;
    l_temp = ((this->CANdata64) & (~mask));

    this->CANdata64 = (l_temp | (uint64_t)(((uint64_t)data) << startBitPos));

     
}

void ROS_CAN ::settingDataOntoCAN_2(uint16_t data, uint16_t Length, uint8_t startBitPos) // for setting CANdata size > 8 bit
{
    uint64_t l_temp, mask;
    uint16_t i;
    for (i = 0; i < Length; i++)
    {
        mask = ((1 << i) | mask);
    }
    mask = (mask) << startBitPos;
    l_temp = ((this->CANdata64) & (~mask));

    this->CANdata64 = (l_temp | (uint64_t)(((uint64_t)data) << startBitPos));

}

// void ROS_CAN ::settingDataOntoCAN_2_motorolla(uint16_t data, uint16_t Length, uint8_t startBitPos) // for setting CANdata size > 8 bit
// {
//     uint64_t l_temp, mask;
//     uint16_t i;
//     uint8_t local_sb = startBitPos;
// 	for (i = 0; i < Length; i++)
// 	{
// 		l_temp = (data & (1 <<i)) << (local_sb + i);
// 		if((local_sb +i)%8)
// 		{
// 			local_sb = local_sb + i -15;			
// 	}
// 	this->CANdata64 |= l_temp;

// }


void ROS_CAN ::Convert64To8arrays(void)
{
    this->aCANdata8[0] = (uint8_t)(((this->CANdata64) >> 0) & 0xFF);
    this->aCANdata8[1] = (uint8_t)(((this->CANdata64) >> 8) & 0xFF);
    this->aCANdata8[2] = (uint8_t)(((this->CANdata64) >> 16) & 0xFF);
    this->aCANdata8[3] = (uint8_t)(((this->CANdata64) >> 24) & 0xFF);
    this->aCANdata8[4] = (uint8_t)(((this->CANdata64) >> 32) & 0xFF);
    this->aCANdata8[5] = (uint8_t)(((this->CANdata64) >> 40) & 0xFF);
    this->aCANdata8[6] = (uint8_t)(((this->CANdata64) >> 48) & 0xFF);
    this->aCANdata8[7] = (uint8_t)(((this->CANdata64) >> 56) & 0xFF);
}
uint8_t *ROS_CAN ::GetCANData8(void)
{
    return (this->aCANdata8);
}
uint32_t PhysicalToRawConversion(float Phy_val, float offset, float factor)
{
    uint32_t RAW_data;
    //ROS_INFO("Physical Value : %f", Phy_val);
    RAW_data = (Phy_val - (offset)) / factor; // type casting?
    //ROS_INFO("Raw Value : %x", RAW_data);
    return RAW_data;
}


class Encode_CAN_Msg
{
public:
    Encode_CAN_Msg(ros::NodeHandle* nodehandle ); //"main" will need to instantiate a ROS nodehandle, then pass it to the constructor
    

    void initializeEncode_CAN_MsgSubscribers();
    void initializeEncode_CAN_MsgPublishers();

    ros::Subscriber SubscribeVehicleControl;
    uint8_t *input_data_DO[8];
    can_msgs::Frame DOData;

    ros::Publisher CANPublisher;	
    can_msgs::Frame frame;
    ace_msgs::VehicleControl VehicleControlDATA;

    ROS_CAN BCU;
    void reset_BCU_Variables();

    
    void VehicleControlCallback(const ace_msgs::VehicleControl &VehicleControlDATA); // the callback function
    void sendCAN_Steering(float torque_value);
    void sendCAN_Throttle(float vehicle_speed);
    float map(float x, float in_min, float in_max, float out_min, float out_max);
       
    // may choose to define public methods or public variables, if desired
private:
    // put private member data here;  "private" data will only be available to member functions of this class;
    ros::NodeHandle n,nh_param; // we will need this, to pass between "main" and constructor
    


}; // note: a class definition requires a semicolon at the end of the definition

