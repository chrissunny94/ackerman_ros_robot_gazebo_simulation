#!/bin/sh

#git pull
git config --global credential.helper 'cache --timeout=3600'

git add .
git add -A

git commit -m "$1"
git push  -u origin development

